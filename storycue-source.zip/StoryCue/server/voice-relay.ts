import { closeDetachedAsrSocket } from "./asr-socket-lifecycle";
import { PlaybackEchoGuard } from "../src/lib/voice/playback-echo-guard";
import { interviewCommitDelay, interviewVoiceDirection, TRIAL_VOICES, type TurnTaking, type VoiceDelivery } from "../src/lib/voice/trial-settings";
import { judgeSemanticTurn, semanticWaitMs, type SemanticDecision, type SemanticProvider } from "./semantic-turn-taking";
/**
 * WebSocket relay server using separate ASR 2.0 + TTS 2.0 services.
 *
 * Browser ←→ this relay ←→ Volcengine ASR 2.0 (speech recognition)
 *                         ←→ Volcengine TTS 2.0 (speech synthesis)
 *                         ←→ Gemini / Kimi / MiniMax LLM (response generation)
 *
 * Architecture (Phase 2 — cost-optimized):
 *   - ASR via Volcengine BigModel streaming ASR (volcengine-asr.ts)
 *   - TTS via Volcengine SeedTTS 2.0 HTTP streaming (volcengine-tts.ts)
 *   - Chat intelligence via external LLM (unchanged from Phase 1)
 *
 * Key features:
 * - Per-question interview flow with LLM-powered context summarization
 * - Transition triggers from both user (button/voice) and agent (keyword detection)
 * - Barge-in / interruption: ASR activity cancels in-flight TTS
 * - Accumulated context passed between questions
 *
 * Usage:  npx tsx server/voice-relay.ts
 */
import { randomUUID } from "crypto";
import { config } from "dotenv";
import { WebSocket, WebSocketServer } from "ws";
import { maxFollowUpsForDepth } from "../src/lib/follow-up-depth";
import { bt } from "../src/lib/i18n";
import { createLogger } from "../src/lib/logger";
import { callRelayLLM, logRelayLlmStartup } from "./relay-llm";
import {
    activeSpeechHoldAction,
    asrPendingFinalDelayMs,
    collapseInternalAsrRepetitions,
    countFollowUpsSpent,
    createAsrSessionState,
    deriveAsrSessionUpdate,
    finalizeTurnBudgetResponse,
    hasAnsweredCurrentQuestion,
    isAsrRollingRevision,
    isUserEndRequest,
    isUserSkipRequest,
    markAsrSessionCommitted,
    mergeAsrSegments,
    playbackAckFallbackMs,
    questionAwaitingSummary,
    resetAsrSessionState,
    responseInvitesUserReply,
    shouldHoldBargeInInterimForFinal,
    shouldSuppressAnsweredAsrFinal,
    shouldSuppressRecentAsrFinal,
    trimCrossTurnOverlap,
    type RecentAsrFinal,
} from "./voice-relay-helpers";
import { PROMPTS, SPOKEN } from "./voice-relay-prompts";
import {
    BIGMODEL_ASR_URL,
    buildBigModelAudioRequest,
    buildBigModelFullRequest,
    buildBigModelHeaders,
    parseAsrResponse,
    resolveBigModelAsrLanguage,
    type BigModelAsrConfig,
} from "./volcengine-asr";
import {
    resolveTtsAuthConfig,
    isTtsAuthConfigured,
    resolveTtsSpeechRate,
    synthesizeSpeech,
    type TtsAuthConfig,
    type TtsSynthesisOptions,
} from "./volcengine-tts";

const log = createLogger("voice-relay");

config({ path: ".env.local", override: true });
config({ path: ".env" });

// AbortController.abort() in Node.js can cause unhandled rejections from
// fetch internals — these are expected during TTS barge-in cancellation.
process.on("unhandledRejection", (reason) => {
  if (reason instanceof DOMException && reason.name === "AbortError") return;
  log.error("Unhandled rejection:", reason);
});

// ── Configuration ───────────────────────────────────────────────────

const RELAY_PORT = Number(process.env.VOICE_RELAY_PORT) || 8766;

// ASR config — X-Api-Key auth (new console) for ASR 2.0
const ASR_APP_ID = process.env.DOUBAO_APP_ID || process.env.DOUBAO_APP_KEY || "";
const ASR_ACCESS_TOKEN = process.env.DOUBAO_ACCESS_TOKEN || "";
/** BigModel streaming ASR only accepts X-Api-Key auth; App ID + Access Token returns HTTP 400. */
const ASR_API_KEY = process.env.DOUBAO_API_KEY || "";
const ASR_RESOURCE_ID = process.env.DOUBAO_ASR_RESOURCE_ID || "volc.seedasr.sauc.duration";

/** Volc BigModel endpointing / speech timing bounds (ms). Docs: min 200ms for end window. */
const ASR_ENDPOINT_MIN_MS = 200;
/**
 * Silence before the provider endpoints a segment, at the docs' recommended default. Endpointing
 * early is cheap now that a resumed segment merges back into the same turn, and it is the largest
 * single contributor to turn-taking latency. Override: DOUBAO_ASR_END_WINDOW_MS.
 */
const ASR_END_WINDOW_DEFAULT_MS = 800;
const ASR_END_WINDOW_MAX_MS = 6_000;
const ASR_FORCE_SPEECH_DEFAULT_MS = 1000;
const ASR_FORCE_SPEECH_MAX_MS = 60_000;

/**
 * Volc BigModel: silence longer than end_window_size (ms) forces definite=true and ends the turn.
 * Override: DOUBAO_ASR_END_WINDOW_MS
 */
const ASR_END_WINDOW_MS = Math.max(
  ASR_ENDPOINT_MIN_MS,
  Math.min(
    ASR_END_WINDOW_MAX_MS,
    Number(process.env.DOUBAO_ASR_END_WINDOW_MS) || ASR_END_WINDOW_DEFAULT_MS,
  ),
);
/**
 * Volc BigModel force_to_speech_time (ms) is a floor, not a cap: a segment shorter than this is
 * never endpointed, so it stops half-second blips from becoming their own turns. Docs recommend
 * 1000 and require at least 1. Override: DOUBAO_ASR_FORCE_SPEECH_MS
 */
const parsedForceSpeechMs = Number(process.env.DOUBAO_ASR_FORCE_SPEECH_MS);
const ASR_FORCE_SPEECH_MS = Number.isFinite(parsedForceSpeechMs)
  ? Math.max(0, Math.min(ASR_FORCE_SPEECH_MAX_MS, parsedForceSpeechMs))
  : ASR_FORCE_SPEECH_DEFAULT_MS;
const MIC_TEST_ASR_END_WINDOW_MS = Math.min(800, ASR_END_WINDOW_MS);
const MIC_TEST_ASR_IDLE_KEEPALIVE_MS = 1_000;
/** Roughly 10s of 200ms uplink frames held while ASR is still becoming ready. */
const ASR_MAX_PENDING_CHUNKS = 50;
/**
 * Hold after a definite segment before committing the turn, so a short pause mid-answer can still
 * merge into the same utterance. Authoritative session reassembly means a resumed segment rejoins
 * the turn intact, so this only needs to cover the gap where someone draws breath mid-sentence.
 */
const ASR_FINAL_COALESCE_MS = Math.max(
  0,
  Math.min(
    5_000,
    Number(process.env.DOUBAO_ASR_FINAL_COALESCE_MS) || 1_500,
  ),
);
/**
 * Long answers get a wider window than the normal path: people draw breath and think mid-sentence
 * more often the longer they talk, and committing during one of those pauses cuts the answer in
 * half. With end_window_size this tolerates a ~3.8s pause before the turn is handed to the LLM.
 */
const ASR_LONG_FINAL_COALESCE_MS = Math.max(
  ASR_FINAL_COALESCE_MS,
  Math.min(
    8_000,
    Number(process.env.DOUBAO_ASR_LONG_FINAL_COALESCE_MS) || 3_000,
  ),
);
const ASR_SHORT_FINAL_COALESCE_MS = Math.max(
  0,
  Math.min(
    ASR_FINAL_COALESCE_MS,
    Number(process.env.DOUBAO_ASR_SHORT_FINAL_COALESCE_MS) || 300,
  ),
);
const ASR_ACTIVE_SPEECH_HOLD_MS = Math.max(
  0,
  Math.min(
    3_000,
    Number(process.env.DOUBAO_ASR_ACTIVE_SPEECH_HOLD_MS) || 600,
  ),
);
const ASR_PENDING_FINAL_QUIET_MS = Math.max(
  ASR_ACTIVE_SPEECH_HOLD_MS,
  Math.min(
    4_000,
    Number(process.env.DOUBAO_ASR_PENDING_FINAL_QUIET_MS) || 800,
  ),
);
/**
 * Backstop for the failure mode where the provider never reports `definite` at all: how long an
 * interim may sit unchanged, with a quiet microphone, before the relay endpoints the turn itself.
 * Deliberately several times end_window_size — normal endpointing arrives ~800ms after speech
 * stops, so this should only ever fire when that is broken. Tightening it turns the backstop into
 * a competing endpointer that splits answers at ordinary mid-sentence pauses.
 */
const ASR_INTERIM_STALL_COMMIT_MS = Math.max(
  0,
  Math.min(
    20_000,
    Number(process.env.DOUBAO_ASR_INTERIM_STALL_COMMIT_MS) || 4_000,
  ),
);
const ASR_MAX_ACTIVE_SPEECH_HOLD_MS = Math.max(
  0,
  Math.min(
    120_000,
    Number(process.env.DOUBAO_ASR_MAX_ACTIVE_SPEECH_HOLD_MS) || 60_000,
  ),
);
const ASR_AUDIO_ACTIVITY_RMS_THRESHOLD = Math.max(
  0,
  Math.min(
    1,
    Number(process.env.DOUBAO_ASR_AUDIO_ACTIVITY_RMS_THRESHOLD) || 0.018,
  ),
);
const ASR_SESSION_MAX_CONTINUOUS_SPEECH_MS = Math.max(
  10_000,
  Math.min(
    120_000,
    Number(process.env.DOUBAO_ASR_SESSION_MAX_CONTINUOUS_SPEECH_MS) || 30_000,
  ),
);
const ASR_STUCK_TEXT_ROTATE_MS = Math.max(
  3_000,
  Math.min(
    15_000,
    Number(process.env.DOUBAO_ASR_STUCK_TEXT_ROTATE_MS) || 5_000,
  ),
);
const ASR_RECENT_FINAL_REPLAY_TTL_MS = 90_000;
const ASR_RECENT_FINAL_REPLAY_MIN_UNITS = 8;

/**
 * Volc split-noise finals often arrive soon after the assistant line is committed; after this much
 * wall time since that line, treat the user final as a real reply (no phrase-shape / keyword rules).
 */
const SPLIT_NOISE_MIN_PAUSE_AFTER_ASSISTANT_MS = 5500;

// TTS config
const TTS_APP_ID = process.env.DOUBAO_APP_ID || "";
const TTS_ACCESS_TOKEN = process.env.DOUBAO_ACCESS_TOKEN || "";
const TTS_API_KEY = process.env.DOUBAO_API_KEY || "";
const TTS_RESOURCE_ID = process.env.DOUBAO_TTS_RESOURCE_ID || "seed-tts-2.0";
const TTS_VOICE_ZH = process.env.DOUBAO_VOICE_ZH || "";
const TTS_VOICE_EN = process.env.DOUBAO_VOICE_EN || "";
const TTS_SPEECH_RATE = resolveTtsSpeechRate();

function getTtsAuth(): TtsAuthConfig {
  return resolveTtsAuthConfig({
    appId: TTS_APP_ID,
    accessToken: TTS_ACCESS_TOKEN,
    apiKey: TTS_API_KEY,
    resourceId: TTS_RESOURCE_ID,
  });
}

function getTtsOptions(language?: string, ctx?: InterviewContext, latestAnswer = ""): TtsSynthesisOptions {
  const isZh = language?.toLowerCase().startsWith("zh");
  const defaultVoice = isZh
    ? "zh_female_shuangkuaisisi_uranus_bigtts"
    : "en_female_dacey_uranus_bigtts";
  const voiceType = (isZh ? TTS_VOICE_ZH : TTS_VOICE_EN) || defaultVoice;
  const direction = isZh ? interviewVoiceDirection(ctx?.voiceDelivery, latestAnswer) : undefined;
  return {
    speaker: isZh && TRIAL_VOICES.some(v => v.id === ctx?.voiceId) ? ctx!.voiceId! : voiceType,
    format: "pcm",
    sampleRate: 24000,
    ...(TTS_SPEECH_RATE != null ? { speechRate: TTS_SPEECH_RATE } : {}),
    ...(direction ? { speechRate: 0, contextTexts: [direction] } : {}),
  };
}

if (!ASR_API_KEY) {
  log.error("Missing DOUBAO_API_KEY in .env.local (required for BigModel streaming ASR)");
  process.exit(1);
}
if (!isTtsAuthConfigured({ appId: TTS_APP_ID, accessToken: TTS_ACCESS_TOKEN, apiKey: ASR_API_KEY })) {
  log.error("Missing DOUBAO_APP_ID or DOUBAO_ACCESS_TOKEN in .env.local (required for TTS)");
  process.exit(1);
}

// ── Interview context type ──────────────────────────────────────────

interface InterviewContext {
  title: string;
  objective?: string | null;
  aiName: string;
  aiTone: string;
  language: string;
  followUpDepth: string;
  interviewStyle?: "STORY";
  turnTaking?: TurnTaking;
  turnProvider?: SemanticProvider;
  voiceId?: string;
  voiceDelivery?: VoiceDelivery;
  startQuestionIndex?: number;
  questions: Array<{
    text: string;
    type: string;
    description?: string | null;
    options?: { options: string[]; allowMultiple?: boolean } | null;
    order: number;
  }>;
}

interface TranscriptEntry {
  role: "user" | "assistant";
  text: string;
}

function normalizeUtteranceForEcho(s: string): string {
  return s.replace(/\s+/g, " ").trim().toLowerCase();
}

/** Volc often picks up played TTS; avoid treating that as a user line on suppression flush. */
function looksLikeAssistantPlaybackEcho(userText: string, transcript: TranscriptEntry[]): boolean {
  const u = normalizeUtteranceForEcho(userText);
  if (u.length < 10) return false;
  for (let i = transcript.length - 1; i >= Math.max(0, transcript.length - 4); i--) {
    const e = transcript[i];
    if (e?.role !== "assistant" || !e.text) continue;
    const a = normalizeUtteranceForEcho(e.text);
    if (!a) continue;
    if (a.includes(u)) return true;
    if (u.length >= 28 && u.includes(a.slice(0, Math.min(36, a.length)))) return true;
  }
  return false;
}

interface AgentContext {
  memory: string;
  codeContent?: string;
  codeLanguage?: string;
  whiteboardDescription?: string;
  whiteboardLoading?: boolean;
  correctionGuard?: string;
  antiRepetition?: string;
}

// ── Vision LLM for whiteboard description ────────────────────────────

const VISION_LLM_API_KEY = process.env.KIMI_API_KEY || "";
const VISION_LLM_BASE_URL = process.env.KIMI_BASE_URL || "https://api.moonshot.cn/v1";
const VISION_LLM_MODEL = process.env.VISION_LLM_MODEL || "kimi-k2.5";
/** Used when the primary model returns empty text after parsing (vision-specific, shorter path to answer). */
const VISION_LLM_RETRY_MODEL = process.env.VISION_LLM_RETRY_MODEL || "moonshot-v1-8k-vision-preview";
const VISION_LLM_MAX_TOKENS = 1024;
const WHITEBOARD_SNAPSHOT_REQUEST_TIMEOUT_MS = 2500;
const WHITEBOARD_VISION_INLINE_TIMEOUT_MS = 1200;
const WHITEBOARD_VISION_FOLLOW_UP_MAX_WAIT_MS = 20_000;

/** Kimi API rejects custom temperature for these models — omit the field (see kimi.ts / vision-compare). */
const VISION_MODELS_OMIT_TEMPERATURE = new Set(["kimi-k2.5"]);

/**
 * Strip Kimi-style redacted reasoning blocks (see scripts/vision-compare stripThinking).
 * Low max_tokens can leave the whole completion inside one — second replace clears that tail.
 */
function stripVisionReasoning(text: string): string {
  let result = text.replace(/<think>[\s\S]*?<\/think>\s*/gi, "").trim();
  result = result.replace(/<think>[\s\S]*/gi, "").trim();
  return result;
}

function normalizeChatMessageContent(content: unknown): string {
  if (content == null) return "";
  if (typeof content === "string") return content;
  if (!Array.isArray(content)) return "";
  const parts: string[] = [];
  for (const part of content) {
    if (typeof part === "string") {
      parts.push(part);
      continue;
    }
    if (part && typeof part === "object" && "type" in part) {
      const p = part as { type?: string; text?: string };
      if (p.type === "text" && typeof p.text === "string") parts.push(p.text);
    }
  }
  return parts.join("");
}

async function callWhiteboardVisionApi(
  imageDataUrl: string,
  userPrompt: string,
  model: string,
): Promise<{ text: string; finishReason?: string }> {
  const omitTemp = VISION_MODELS_OMIT_TEMPERATURE.has(model);
  const body: Record<string, unknown> = {
    model,
    messages: [
      {
        role: "user",
        content: [
          { type: "image_url", image_url: { url: imageDataUrl } },
          { type: "text", text: userPrompt },
        ],
      },
    ],
    max_tokens: VISION_LLM_MAX_TOKENS,
  };
  if (!omitTemp) {
    body.temperature = 0.2;
  }

  const res = await fetch(`${VISION_LLM_BASE_URL}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${VISION_LLM_API_KEY}`,
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const errBody = await res.text().catch(() => "");
    log.error(`Vision LLM error (${model}): ${res.status} — ${errBody.slice(0, 200)}`);
    return { text: "" };
  }

  const data = (await res.json()) as {
    choices?: Array<{ message?: { content?: unknown }; finish_reason?: string }>;
  };
  const choice = data?.choices?.[0];
  const raw = normalizeChatMessageContent(choice?.message?.content);
  const text = stripVisionReasoning(raw).trim();
  return { text, finishReason: choice?.finish_reason };
}

async function describeWhiteboard(imageDataUrl: string, isZh: boolean): Promise<string> {
  if (!VISION_LLM_API_KEY || !imageDataUrl) return "";

  const userPrompt = isZh
    ? "用1-2句话描述这个白板上画了什么。重点说明结构、组件和它们之间的关系。只输出描述本体，不要输出思考过程。"
    : "Describe what is drawn on this whiteboard in 1-2 sentences. Focus on the structure, components, and relationships shown. Output only the description itself, no reasoning or preamble.";

  const startMs = Date.now();
  try {
    let { text, finishReason } = await callWhiteboardVisionApi(
      imageDataUrl,
      userPrompt,
      VISION_LLM_MODEL,
    );

    if (
      !text &&
      VISION_LLM_RETRY_MODEL &&
      VISION_LLM_RETRY_MODEL !== VISION_LLM_MODEL
    ) {
      log.warn(
        `Vision LLM (${VISION_LLM_MODEL}) returned empty${finishReason ? ` (finish=${finishReason})` : ""} — retrying with ${VISION_LLM_RETRY_MODEL}`,
      );
      ({ text, finishReason } = await callWhiteboardVisionApi(
        imageDataUrl,
        userPrompt,
        VISION_LLM_RETRY_MODEL,
      ));
    }

    const elapsed = Date.now() - startMs;
    if (!text) {
      log.warn(
        `Vision LLM returned empty (${elapsed}ms)${finishReason ? ` finish=${finishReason}` : ""}`,
      );
      return "";
    }

    log.info(
      `Vision LLM (${elapsed}ms): "${text.length > 80 ? `${text.slice(0, 80)}…` : text}"`,
    );
    return text;
  } catch (err) {
    log.error("Vision LLM failed:", err);
    return "";
  }
}

// ── Correction detection ─────────────────────────────────────────────

const CORRECTION_PATTERNS_ZH = [
  /请重新/i, /请选择/i, /只能选一个/i, /请再想想/i,
  /需要选择/i, /请再考虑/i, /选择一个/i, /不太对/i,
];
const CORRECTION_PATTERNS_EN = [
  /please reconsider/i, /choose only one/i, /pick (?:only )?one/i,
  /need to (?:select|choose|pick)/i, /try again/i, /that'?s not quite/i,
  /please select/i, /must pick/i, /can only choose one/i,
];

function isCorrection(text: string, isZh: boolean): boolean {
  const patterns = isZh ? CORRECTION_PATTERNS_ZH : CORRECTION_PATTERNS_EN;
  return patterns.some((p) => p.test(text));
}

// ── Repetition detection ─────────────────────────────────────────────

function normalizeForComparison(s: string): string {
  return s.toLowerCase().replace(/[^\w\u4e00-\u9fff]/g, "");
}

function isSimilarResponse(a: string, b: string): boolean {
  const na = normalizeForComparison(a);
  const nb = normalizeForComparison(b);
  if (!na || !nb) return false;
  if (na === nb) return true;
  const shorter = na.length < nb.length ? na : nb;
  const longer = na.length < nb.length ? nb : na;
  return longer.includes(shorter) || shorter.length / longer.length > 0.8;
}

// ── Transition detection ────────────────────────────────────────────

const FAST_NEXT_PATTERNS = [
  /^(?:下一个问题|下一题|跳过|next\s*question|skip)\.?$/i,
];

const FAST_PREV_PATTERNS = [
  /^(?:上一个问题|上一题|previous\s*question)\.?$/i,
];

const USER_PREV_PATTERNS = [
  /(?:go|move|get)\s+back\s+(?:to\s+)?(?:the\s+)?(?:previous|last|prior)/i,
  /(?:return|go)\s+to\s+(?:the\s+)?(?:previous|last|prior)\s+(?:question|one|problem)/i,
  /(?:can|could)\s+(?:we|you|i)\s+(?:go|move|get)\s+back/i,
  /(?:let'?s|please|i\s+(?:want|need)\s+to)\s+(?:go|move|get)\s+back/i,
  /(?:revisit|re-visit)\s+(?:the\s+)?(?:previous|last|prior)/i,
  /previous\s+question/i,
  /(?:回到|返回|回去)(?:上一(?:个问题|题)|之前(?:的问题|那题))/,
  /(?:我(?:想|要|需要)|请|可以)(?:回到|返回|回去)上一/,
];

const IMPLICIT_NEXT_PATTERNS = [
  /let'?s\s+(?:move|proceed|go)\s+(?:on|forward)\s+(?:to\s+)?(?:the\s+)?next/i,
  /(?:move|proceed|go)\s+to\s+the\s+next\s+question/i,
  /we(?:'ll|\s+will)\s+(?:move|proceed|go)\s+(?:on|to\s+the\s+next)/i,
  /我们(?:进入|开始|来看)下一(?:个问题|题)/,
  /(?:进入|开始)下一(?:个问题|题)/,
  /那我们(?:继续|进入)下一/,
];

function hasImplicitTransition(text: string): boolean {
  return IMPLICIT_NEXT_PATTERNS.some((p) => p.test(text));
}

const IMPLICIT_PREV_PATTERNS = [
  /(?:go|going)\s+back\s+to\s+(?:the\s+)?previous/i,
  /(?:return|returning)\s+to\s+(?:the\s+)?previous/i,
  /(?:revisit|re-visit)\s+(?:the\s+)?previous/i,
  /(?:let'?s|we(?:'ll|\s+can))\s+(?:go\s+back|return|revisit)/i,
  /(?:回到|返回|回去)(?:上一(?:个问题|题)|之前(?:的问题|那题))/,
  /我们(?:回到|返回)上一/,
];

function hasImplicitPrevTransition(text: string): boolean {
  return IMPLICIT_PREV_PATTERNS.some((p) => p.test(text));
}

function looksLikeQuestion(text: string): boolean {
  if (/[？?]/.test(text)) return true;
  if (/\b(?:could|can|would)\s+you\s+(?:share|explain|elaborate|describe|tell|walk|talk|give|provide)/i.test(text)) return true;
  if (/\bplease\s+(?:share|explain|elaborate|describe|tell|walk|talk|give|provide)/i.test(text)) return true;
  if (/\b(?:how|what|why|where|when)\s+(?:do|did|does|would|could|can|will|is|are|was|were)\s+(?:you|they|the|this|that|it)\b/i.test(text)) return true;
  if (/请.{0,4}(?:分享|描述|解释|说明|告诉|讲述?|谈谈?)/.test(text)) return true;
  if (/能否.{0,4}(?:分享|描述|解释|说明|告诉|讲述?|谈谈?)/.test(text)) return true;
  return false;
}

function replyKeepsConversationOpen(text: string, isZh: boolean): boolean {
  return looksLikeQuestion(text) || responseInvitesUserReply(text, isZh);
}

function isFastNextRequest(text: string): boolean {
  const t = text.trim();
  return FAST_NEXT_PATTERNS.some((p) => p.test(t));
}

function isFastPrevRequest(text: string): boolean {
  const t = text.trim();
  return FAST_PREV_PATTERNS.some((p) => p.test(t));
}

function isUserPrevRequest(text: string): boolean {
  return USER_PREV_PATTERNS.some((p) => p.test(text));
}

let lastContinuationFragmentLog: { text: string; at: number } | null = null;
function logContinuationFragmentIgnored(text: string): void {
  const t = text.trim();
  const now = Date.now();
  if (
    lastContinuationFragmentLog &&
    lastContinuationFragmentLog.text === t &&
    now - lastContinuationFragmentLog.at < 2_000
  ) {
    return;
  }
  lastContinuationFragmentLog = { text: t, at: now };
  log.info(
    `ASR split-noise: ignoring short follow-up final after long user turn: "${t.slice(0, 72)}..."`,
  );
}

/**
 * Volc often emits a second definite soon after the first — a tail fragment or noise — especially
 * after a short TTS segment. If the new final arrives soon after the latest *transcript* assistant
 * line, treat obvious mid-phrase tails as noise; after SPLIT_NOISE_MIN_PAUSE_AFTER_ASSISTANT_MS,
 * the same text is handled as a real user reply (pause-based, no keyword allowlist).
 */
function shouldIgnoreVolcContinuationFragment(
  text: string,
  transcript: TranscriptEntry[],
  lastAssistantMessageAtMs: number,
  isZhLocale: boolean,
): boolean {
  const t = text.trim();
  if (t.length < 2) return false;
  if (
    isUserEndRequest(t) ||
    isUserSkipRequest(t) ||
    isFastNextRequest(t) ||
    isFastPrevRequest(t) ||
    isUserPrevRequest(t)
  ) {
    return false;
  }

  const now = Date.now();
  if (lastAssistantMessageAtMs <= 0) return false;
  const pauseAfterAssistant = now - lastAssistantMessageAtMs;
  if (pauseAfterAssistant >= SPLIT_NOISE_MIN_PAUSE_AFTER_ASSISTANT_MS) return false;

  let lastUserIdx = -1;
  for (let i = transcript.length - 1; i >= 0; i--) {
    if (transcript[i].role === "user") {
      lastUserIdx = i;
      break;
    }
  }
  if (lastUserIdx < 0) return false;

  const lastUser = transcript[lastUserIdx].text.trim();
  const hadAssistantAfter = transcript
    .slice(lastUserIdx + 1)
    .some((e) => e.role === "assistant");
  if (!hadAssistantAfter) return false;

  if (isZhLocale) {
    const compactLast = lastUser.replace(/\s+/g, "");
    const compactT = t.replace(/\s+/g, "");
    if (compactLast.length < 40) return false;
    if (compactT.length < 8 || compactT.length > 36) return false;
  } else {
    if (lastUser.length < 70) return false;
    const wc = t.split(/\s+/).filter(Boolean).length;
    if (t.length > 52 || wc > 8) return false;

    const looksLikeMidPhraseTail =
      /^(?:and|or|but|if|for|to)\s+/i.test(t) ||
      /^(?:the|a|an)\s+\w+\s*\.?\s*$/i.test(t);

    if (!looksLikeMidPhraseTail) return false;
  }

  logContinuationFragmentIgnored(t);
  return true;
}

// ── Build prompts from interview context ─────────────────────────────

function isChineseInterview(ctx: InterviewContext): boolean {
  return (
    ctx.language === "zh" || ctx.language.toLowerCase().includes("chinese")
  );
}

function buildChoiceSuffix(
  type: string,
  opts: { options: string[]; allowMultiple?: boolean } | null | undefined,
  isZh: boolean,
): string {
  if (
    (type !== "SINGLE_CHOICE" && type !== "MULTIPLE_CHOICE") ||
    !opts?.options?.length
  ) {
    return "";
  }
  const labels = opts.options
    .map((o, i) => `${String.fromCharCode(65 + i)}, ${o}`)
    .join("; ");
  return bt(isZh, type === "MULTIPLE_CHOICE"
    ? SPOKEN.multipleChoiceSuffix(labels)
    : SPOKEN.singleChoiceSuffix(labels));
}

function buildGreeting(ctx: InterviewContext): string {
  const isZh = isChineseInterview(ctx);
  const firstQ = ctx.questions.sort((a, b) => a.order - b.order)[0];
  const q1Text = firstQ?.text || bt(isZh, SPOKEN.defaultQuestion);

  const opts = firstQ?.options as { options: string[]; allowMultiple?: boolean } | null | undefined;
  const isCodingOrWb = firstQ && (firstQ.type === "CODING" || firstQ.type === "WHITEBOARD");
  const spokenQuestion = isCodingOrWb
    ? bt(isZh, SPOKEN.codingWbIntro(firstQ.type))
    : `${q1Text}${buildChoiceSuffix(firstQ?.type ?? "", opts, isZh)}`;

  return bt(isZh, SPOKEN.greeting(ctx.aiName, ctx.title, ctx.questions.length, spokenQuestion));
}

function buildTransitionSayHello(
  questionIndex: number,
  nextQuestion: { text: string; type: string; options?: { options: string[]; allowMultiple?: boolean } | null },
  isZh: boolean
): string {
  const isCodingOrWb = nextQuestion.type === "CODING" || nextQuestion.type === "WHITEBOARD";
  const opts = nextQuestion.options as { options: string[]; allowMultiple?: boolean } | null | undefined;
  const qNum = questionIndex + 1;

  if (isCodingOrWb) {
    return bt(isZh, SPOKEN.transition.codingWb(qNum, bt(isZh, SPOKEN.codingWbIntro(nextQuestion.type))));
  }
  return bt(isZh, SPOKEN.transition.normal(qNum, nextQuestion.text, buildChoiceSuffix(nextQuestion.type, opts, isZh)));
}

function buildResumeGreeting(ctx: InterviewContext, questionIndex: number): string {
  const isZh = isChineseInterview(ctx);
  const sortedQs = ctx.questions.sort((a, b) => a.order - b.order);
  const q = sortedQs[questionIndex];
  const qNum = questionIndex + 1;

  const opts = q?.options as { options: string[]; allowMultiple?: boolean } | null | undefined;
  const isCodingOrWb = q && (q.type === "CODING" || q.type === "WHITEBOARD");

  if (isCodingOrWb) {
    return bt(isZh, SPOKEN.resume.codingWb(qNum, bt(isZh, SPOKEN.codingWbIntro(q.type))));
  }
  return bt(isZh, SPOKEN.resume.normal(qNum, q?.text || "", buildChoiceSuffix(q?.type ?? "", opts, isZh)));
}

function buildReturnSayHello(
  questionIndex: number,
  question: { text: string; type: string; options?: { options: string[]; allowMultiple?: boolean } | null },
  isZh: boolean
): string {
  const isCodingOrWb = question.type === "CODING" || question.type === "WHITEBOARD";
  const qNum = questionIndex + 1;

  if (isCodingOrWb) {
    return bt(isZh, SPOKEN.returnTo.codingWb(qNum, bt(isZh, SPOKEN.codingWbIntro(question.type, "continue"))));
  }

  const opts = question.options as { options: string[]; allowMultiple?: boolean } | null | undefined;
  let optionsSuffix = "";
  const isChoice = question.type === "SINGLE_CHOICE" || question.type === "MULTIPLE_CHOICE";
  if (isChoice && opts?.options?.length) {
    const labels = opts.options.map((o, i) => `${String.fromCharCode(65 + i)}, ${o}`).join("; ");
    optionsSuffix = bt(isZh, SPOKEN.optionsList(labels));
  }
  return bt(isZh, SPOKEN.returnTo.normal(qNum, question.text, optionsSuffix));
}

function buildWrapUpSayHello(isZh: boolean): string {
  return bt(isZh, SPOKEN.wrapUp);
}

function buildFarewellSayHello(isZh: boolean): string {
  return bt(isZh, SPOKEN.farewell);
}

async function summarizeQuestion(
  questionText: string,
  transcript: TranscriptEntry[],
  isZh: boolean
): Promise<string> {
  if (transcript.length === 0) return "";

  const t = transcript
    .map((m) => `${m.role === "user" ? "Participant" : "Interviewer"}: ${m.text}`)
    .join("\n");

  // Local interviews retain the actual exchange; navigating no longer waits for another LLM call.
  if (process.env.AURAL_LOCAL_TRIAL === "1") return t.slice(-2400);

  try {
    const result = await callRelayLLM(bt(isZh, PROMPTS.summarize(questionText, t)));
    log.info(`Q summary: "${result.slice(0, 100)}..."`);
    return result;
  } catch (err) {
    log.error("LLM summarization failed:", err);
    return bt(isZh, PROMPTS.summaryError);
  }
}

// ── Relay server ────────────────────────────────────────────────────

const wss = new WebSocketServer({
  port: RELAY_PORT,
  host: process.env.AURAL_LOCAL_TRIAL === "1" ? "127.0.0.1" : undefined,
  verifyClient: ({ origin }: { origin: string }) => process.env.AURAL_LOCAL_TRIAL !== "1" || !origin || ["http://127.0.0.1:3066", "http://localhost:3066", process.env.NEXT_PUBLIC_APP_URL ? new URL(process.env.NEXT_PUBLIC_APP_URL).origin : ""].includes(origin),
});
log.info(`ASR: resource=${ASR_RESOURCE_ID}, credentialConfigured=${!!ASR_API_KEY}`);
log.info(`ASR VAD: end_window_size=${ASR_END_WINDOW_MS}ms, force_to_speech=${ASR_FORCE_SPEECH_MS}ms`);
log.info(`ASR final coalescing: normal=${ASR_FINAL_COALESCE_MS}ms, long=${ASR_LONG_FINAL_COALESCE_MS}ms, quiet=${ASR_PENDING_FINAL_QUIET_MS}ms, active_speech_hold=${ASR_ACTIVE_SPEECH_HOLD_MS}ms, max_active_hold=${ASR_MAX_ACTIVE_SPEECH_HOLD_MS}ms, session_max_speech=${ASR_SESSION_MAX_CONTINUOUS_SPEECH_MS}ms, stuck_rotate=${ASR_STUCK_TEXT_ROTATE_MS}ms, interim_stall_commit=${ASR_INTERIM_STALL_COMMIT_MS}ms`);
const ttsAuthResolved = getTtsAuth();
log.info(`TTS: resource=${ttsAuthResolved.resourceId}, auth=AppId+AccessKey(${ttsAuthResolved.appId})`);
if (VISION_LLM_API_KEY) {
  log.info(
    `Vision LLM: ${VISION_LLM_MODEL}${VISION_LLM_RETRY_MODEL !== VISION_LLM_MODEL ? ` (retry: ${VISION_LLM_RETRY_MODEL})` : ""}, max_tokens=${VISION_LLM_MAX_TOKENS}`,
  );
}
logRelayLlmStartup();
log.info(`Listening on ws://localhost:${RELAY_PORT}`);

wss.on("connection", (browserWs) => {
  log.info("Browser connected, waiting for init...");

  const timeout = setTimeout(() => {
    log.error("No init message received within 10s");
    browserWs.close();
  }, 10000);

  const handler = (data: Buffer) => {
    try {
      const msg = JSON.parse(data.toString());
      if (msg.type === "mic_test") {
        clearTimeout(timeout);
        browserWs.removeListener("message", handler);
        handleMicTestConnection(browserWs);
      } else if (msg.type === "init" && msg.context) {
        clearTimeout(timeout);
        browserWs.removeListener("message", handler);
        handleBrowserConnection(browserWs, msg.context as InterviewContext);
      }
    } catch {
      // Not JSON, ignore
    }
  };
  browserWs.on("message", handler);
});

// ── Mic test handler (ASR-only, no LLM/TTS) ────────────────────────

async function handleMicTestConnection(browserWs: WebSocket) {
  log.info("Mic test mode");

  let asrWs: WebSocket | null = null;
  let asrAlive = false;
  let asrAudioSeq = 1;
  let keepAliveInterval: ReturnType<typeof setInterval> | null = null;
  const asrSession = createAsrSessionState();
  let intentionalClose = false;
  let asrReconnecting = false;
  let lastAsrAudioSentAt = 0;
  const pendingAudioChunks: Buffer[] = [];

  const autoTimeout = setTimeout(() => {
    log.info("Mic test auto-timeout");
    if (browserWs.readyState === WebSocket.OPEN) {
      browserWs.send(JSON.stringify({ type: "timeout" }));
    }
    cleanup();
  }, 10 * 60 * 1000);

  function cleanup() {
    intentionalClose = true;
    clearTimeout(autoTimeout);
    if (keepAliveInterval) {
      clearInterval(keepAliveInterval);
      keepAliveInterval = null;
    }
    if (asrAlive && asrWs && asrWs.readyState === WebSocket.OPEN) {
      try {
        asrAudioSeq++;
        asrWs.send(buildBigModelAudioRequest(Buffer.alloc(0), asrAudioSeq, true));
      } catch { /* ignore */ }
    }
    closeDetachedAsrSocket(asrWs);
    asrWs = null;
    asrAlive = false;
    pendingAudioChunks.length = 0;
  }

  function sendMicTestAudio(audio: Buffer) {
    if (!asrAlive || !asrWs || asrWs.readyState !== WebSocket.OPEN) {
      pendingAudioChunks.push(audio);
      while (pendingAudioChunks.length > ASR_MAX_PENDING_CHUNKS) {
        pendingAudioChunks.shift();
      }
      return;
    }
    asrAudioSeq++;
    asrWs.send(buildBigModelAudioRequest(audio, asrAudioSeq));
    lastAsrAudioSentAt = Date.now();
  }

  function flushPendingAudio() {
    while (
      pendingAudioChunks.length > 0 &&
      asrAlive &&
      asrWs?.readyState === WebSocket.OPEN
    ) {
      const audio = pendingAudioChunks.shift();
      if (audio) sendMicTestAudio(audio);
    }
  }

  function bindAsrMessageHandlers(ws: WebSocket) {
    ws.on("message", (data: Buffer) => {
      try {
        const resp = parseAsrResponse(Buffer.from(data));

        if (resp.errorCode != null) {
          log.error(`Mic test ASR error: ${resp.errorCode} ${resp.errorMessage}`);
          if (asrWs === ws) {
            asrAlive = false;
            ws.close();
          }
          return;
        }

        // Volcengine repeats every settled segment on each packet, so act on the single
        // uncommitted update rather than re-announcing finished segments.
        const update = deriveAsrSessionUpdate(asrSession, resp);
        if (!update.text || !update.changed) return;

        if (browserWs.readyState === WebSocket.OPEN) {
          browserWs.send(JSON.stringify({
            type: "asr",
            data: { results: [{ text: update.text, definite: update.definite }] },
          }));
          if (update.definite) {
            browserWs.send(JSON.stringify({ type: "asr_ended", text: update.text.trim() }));
          }
        }
        if (update.definite) {
          markAsrSessionCommitted(asrSession);
        }
      } catch (err) {
        log.error("Mic test ASR parse error:", err);
      }
    });

    ws.on("error", (err: Error) => {
      log.error("Mic test ASR error:", err.message);
    });

    ws.on("close", () => {
      asrAlive = false;
      asrWs = null;
      if (intentionalClose || browserWs.readyState !== WebSocket.OPEN || asrReconnecting) {
        return;
      }
      asrReconnecting = true;
      log.info("Mic test ASR closed — reconnecting for continuous transcription");
      void connectMicTestAsr(false)
        .catch((err) => {
          log.error("Mic test ASR reconnect failed:", err);
          if (browserWs.readyState === WebSocket.OPEN) {
            browserWs.send(JSON.stringify({ type: "disconnected" }));
          }
        })
        .finally(() => {
          asrReconnecting = false;
        });
    });
  }

  async function connectMicTestAsr(isInitial: boolean): Promise<void> {
    if (asrWs) {
      closeDetachedAsrSocket(asrWs);
      asrWs = null;
      asrAlive = false;
    }

    const reqid = randomUUID().replace(/-/g, "");
    const asrConfig: BigModelAsrConfig = {
      format: "pcm", rate: 16000, bits: 16, channels: 1, codec: "raw",
      showUtterance: true, resultType: "full", enablePunc: true,
      endWindowSize: MIC_TEST_ASR_END_WINDOW_MS,
      forceToSpeechTime: ASR_FORCE_SPEECH_MS,
    };

    const wsHeaders = buildBigModelHeaders(
      ASR_APP_ID, ASR_ACCESS_TOKEN, reqid, ASR_RESOURCE_ID,
      ASR_API_KEY || undefined,
    );
    const connectStartedAt = Date.now();
    const nextWs = new WebSocket(BIGMODEL_ASR_URL, { headers: wsHeaders });

    await new Promise<void>((resolve, reject) => {
      const t = setTimeout(() => reject(new Error("ASR connect timeout")), 10000);
      nextWs.on("open", () => { clearTimeout(t); resolve(); });
      nextWs.on("error", (e) => { clearTimeout(t); reject(e); });
      nextWs.on("unexpected-response", (_req, res) => {
        let body = "";
        res.on("data", (chunk: Buffer) => { body += chunk.toString(); });
        res.on("end", () => {
          clearTimeout(t);
          log.error(`Mic test ASR rejected: HTTP ${res.statusCode} — ${body}`);
          reject(new Error(`ASR server responded ${res.statusCode}: ${body}`));
        });
      });
    });

    asrAudioSeq = 1;
    // Each websocket reports a cumulative transcript of its own audio only.
    resetAsrSessionState(asrSession);
    asrWs = nextWs;
    nextWs.send(buildBigModelFullRequest(asrConfig, reqid));
    // Prime cold ASR allocation with 100ms of silence before browser audio.
    asrAudioSeq++;
    nextWs.send(buildBigModelAudioRequest(Buffer.alloc(3200), asrAudioSeq));

    asrAlive = true;
    lastAsrAudioSentAt = Date.now();
    bindAsrMessageHandlers(nextWs);
    flushPendingAudio();
    log.info(
      `Mic test ASR primed in ${Date.now() - connectStartedAt}ms${isInitial ? "" : " (reconnected)"}`,
    );

    if (isInitial && browserWs.readyState === WebSocket.OPEN) {
      browserWs.send(JSON.stringify({ type: "ready" }));
    }
  }

  browserWs.on("message", (data) => {
    try {
      const msg = JSON.parse(data.toString());
      if (msg.type === "audio" && msg.data) {
        sendMicTestAudio(Buffer.from(msg.data, "hex"));
      }
    } catch { /* ignore */ }
  });

  browserWs.on("close", () => {
    log.info("Mic test: browser disconnected");
    cleanup();
  });

  try {
    await connectMicTestAsr(true);

    keepAliveInterval = setInterval(() => {
      if (!asrAlive || !asrWs || asrWs.readyState !== WebSocket.OPEN) {
        return;
      }
      if (Date.now() - lastAsrAudioSentAt >= MIC_TEST_ASR_IDLE_KEEPALIVE_MS) {
        sendMicTestAudio(Buffer.alloc(3200));
      }
    }, MIC_TEST_ASR_IDLE_KEEPALIVE_MS / 2);
  } catch (err) {
    log.error("Mic test connection failed:", err);
    if (browserWs.readyState === WebSocket.OPEN) {
      browserWs.send(JSON.stringify({
        type: "error",
        message: `Mic test failed: ${err instanceof Error ? err.message : String(err)}`,
      }));
    }
    browserWs.close();
    cleanup();
  }
}

// ── Interview handler ───────────────────────────────────────────────

async function handleBrowserConnection(browserWs: WebSocket, ctx: InterviewContext) {
  if(ctx.turnTaking==="SEMANTIC" && (process.env.STORYCUE_JEV_ENABLED==="0" || !process.env.TYPESAFE_API_KEY))ctx={...ctx,turnTaking:"PATIENT"};
  // ── ASR state ──────────────────────────────────────────────────
  let asrWs: WebSocket | null = null;
  let asrAlive = false;
  let asrAudioSeq = 1;
  let keepAliveInterval: ReturnType<typeof setInterval> | null = null;

  // ── TTS state ──────────────────────────────────────────────────
  let ttsAbortController: AbortController | null = null;
  let ttsSpeaking = false;
  const playbackEchoGuard = new PlaybackEchoGuard();
  const protectPlayback = ctx.interviewStyle === "STORY";
  let pendingPlaybackAck: {
    utteranceId: string;
    complete: () => void;
  } | null = null;

  // When true, definite ASR results are dropped (only used for barge-in).
  // Set during LLM generation + TTS playback to prevent echo loops.
  // Cleared after barge-in or when the response cycle finishes.
  let suppressAsrResults = false;
  /** Definite user text captured while suppressAsrResults (flushed after reopenAsr). */
  let pendingUserUtteranceWhileSuppressed = "";
  /** User final arrived while handleUserUtterance was already running (asr_ended already sent to client). */
  let queuedUserUtteranceWhileGenerating = "";

  // ── Per-question state ──────────────────────────────────────────
  let currentQuestionIndex = 0;
  const questionSummaries: string[] = [];
  let questionTranscript: TranscriptEntry[] = [];
  const asrSession = createAsrSessionState();
  /**
   * Speech carried over from earlier ASR websockets after a rotation. The current session
   * only reports its own audio, so the pending turn is this prefix plus whatever the live
   * session has transcribed since.
   */
  let pendingAsrFinalPrefix = "";
  let pendingAsrFinalText = "";
  let pendingAsrFinalTimer: ReturnType<typeof setTimeout> | null = null;
  let pendingAsrFinalStartedAt = 0;
  let pendingAsrFinalLastChangedAt = 0;
  let semanticRevision = 0;
  let semanticTimer: ReturnType<typeof setTimeout> | null = null;
  let semanticController: AbortController | null = null;
  let semanticInput = "";
  let semanticResultKey = "";
  let semanticResult: SemanticDecision | null = null;
  let semanticRequestPending = false;
  let lastSemanticRequestAt = 0;
  function clearSemanticDecision() {
    semanticRevision++;
    if (semanticTimer) clearTimeout(semanticTimer);
    semanticTimer = null;
    semanticController?.abort();
    semanticController = null;
    semanticInput = "";
    semanticResultKey = "";
    semanticResult = null;
    semanticRequestPending = false;
  }
  function primeSemanticDecision(text: string) {
    if (ctx.turnTaking !== "SEMANTIC") return;
    const key = normalizeUserUtteranceKey(text);
    if (!key || key === semanticInput) return;
    clearSemanticDecision();
    semanticInput = key;
    semanticRequestPending = true;
    if (browserWs.readyState === WebSocket.OPEN) browserWs.send(JSON.stringify({ type: "turn_decision", choice: "CHECKING", provider: "JEV" }));
    const revision = semanticRevision;
    const provider: SemanticProvider = "JEV";
    semanticTimer = setTimeout(async () => {
      semanticTimer = null;
      const controller = new AbortController();
      semanticController = controller;
      lastSemanticRequestAt = Date.now();
      try {
        const result = await judgeSemanticTurn({ question: sortedQuestions[currentQuestionIndex]?.text ?? "", prompt: [...questionTranscript].reverse().find(e => e.role === "assistant")?.text ?? "", answer: text }, provider, controller.signal);
        if (revision !== semanticRevision || controller.signal.aborted || interviewDone) return;
        semanticResult = result;
        semanticResultKey = key;
        if (browserWs.readyState === WebSocket.OPEN) browserWs.send(JSON.stringify({ type: "turn_decision", choice: result.choice, provider, elapsedMs: result.elapsedMs, quietMs: result.quietMs }));
      } catch (error) {
        if (revision !== semanticRevision || controller.signal.aborted) return;
        // A missing decision retains the floor briefly; never silently impersonate another model.
        semanticResult = null;
        semanticResultKey = key;
        if (browserWs.readyState === WebSocket.OPEN) browserWs.send(JSON.stringify({ type: "turn_decision", choice: "UNAVAILABLE", provider, message: error instanceof Error ? error.message : "Turn detector unavailable" }));
      } finally {
        if (revision === semanticRevision) { semanticRequestPending = false; semanticController = null; }
      }
    }, Math.max(180, 800 - (Date.now() - lastSemanticRequestAt)));
  }
  let asrRotationRecoveryUntil = 0;
  let asrRotationPending = false;
  const pendingAsrRotationAudio: Buffer[] = [];
  /**
   * Backstop for a provider that stops endpointing: the newest interim and when it last grew, so a
   * turn can be committed on our own silence detection instead of waiting for `definite`.
   */
  let asrInterimStallText = "";
  let asrInterimStallChangedAt = 0;
  let asrInterimStallTimer: ReturnType<typeof setTimeout> | null = null;
  let lastUserAudioActivityAt = 0;
  let asrSessionFirstSpeechAt = 0;
  let lastAsrStuckRotationAt = 0;
  let consecutiveDuplicateSkips = 0;
  let heldBargeInInterimText = "";
  let heldBargeInInterimTimer: ReturnType<typeof setTimeout> | null = null;
  let heldBargeInInterimStartedAt = 0;
  let isTransitioning = false;
  let transitionGeneration = 0;
  let pendingManualTransitionDirection: "next" | "previous" | null = null;
  let interviewDone = false;
  let sessionPaused = false;
  let pausedAnswer = "";
  let pausedResponsePending = false;
  let pausedSpeech = "";
  let currentSpeech = "";
  type SpeechActions = { trackInTranscript?: boolean; pendingTransition?: boolean; pendingPrevTransition?: boolean; pendingFarewell?: boolean; pendingFinalTimeout?: boolean };
  let currentSpeechActions: SpeechActions | undefined;
  let pausedSpeechActions: SpeechActions | undefined;
  /** True as soon as we start farewell shutdown; blocks duplicate ASR finals until interviewDone. */
  let endingInterview = false;

  // ── Agent context state ────────────────────────────────────────
  let currentCodeContent = "";
  let currentCodeLanguage = "plaintext";
  let latestWhiteboardImage = "";
  let whiteboardDirty = false;
  let cachedWhiteboardDescription = "";
  let lastResponseWasCorrection = false;
  const recentAgentResponses: string[] = [];
  let pendingWhiteboardVision = false;
  const pendingWhiteboardSnapshotRequests = new Map<string, (hasImage: boolean) => void>();

  // ── Final-response state ──────────────────────────────────────
  let awaitingFinalResponse = false;
  let finalResponseTimeout: ReturnType<typeof setTimeout> | null = null;
  let pendingLastQuestionTimeout: ReturnType<typeof setTimeout> | null = null;

  // ── LLM-controlled response state ─────────────────────────────
  let generatingResponse = false;
  let responseEpoch = 0;
  let responseController: AbortController | null = null;
  let resumedSpeechMs = 0;
  let manualSubmitTimer: ReturnType<typeof setTimeout> | null = null;
  function cancelResponse() {
    responseEpoch++;
    responseController?.abort();
    responseController = null;
    generatingResponse = false;
    resumedSpeechMs = 0;
  }
  let userTurnsOnCurrentQ = 0;
  /** Wall time when the latest assistant line was appended to questionTranscript (split-noise heuristic). */
  let lastAssistantMessageWallClockMs = 0;
  const recentAcceptedUserFinals: RecentAsrFinal[] = [];

  function rememberAcceptedUserFinal(text: string) {
    const finalText = text.replace(/\s+/g, " ").trim();
    if (!finalText) return;

    const last = recentAcceptedUserFinals[recentAcceptedUserFinals.length - 1];
    if (last && shouldSuppressAnsweredAsrFinal(last.text, finalText)) {
      last.text = mergeAsrSegments(last.text, finalText);
      last.at = Date.now();
      return;
    }

    recentAcceptedUserFinals.push({ text: finalText, at: Date.now() });
    while (recentAcceptedUserFinals.length > 8) recentAcceptedUserFinals.shift();
  }

  function shouldSuppressRecentUserFinalReplay(text: string): boolean {
    const currentQuestionAlreadyHasUser = questionTranscript.some((entry) => entry.role === "user");
    if (currentQuestionAlreadyHasUser && !generatingResponse && !suppressAsrResults && !isTransitioning) {
      return false;
    }

    return shouldSuppressRecentAsrFinal(
      text,
      recentAcceptedUserFinals,
      Date.now(),
      {
        ttlMs: ASR_RECENT_FINAL_REPLAY_TTL_MS,
        minComparisonUnits: ASR_RECENT_FINAL_REPLAY_MIN_UNITS,
      },
    );
  }

  function settleWhiteboardSnapshotRequest(requestId: string, hasImage: boolean) {
    const resolve = pendingWhiteboardSnapshotRequests.get(requestId);
    if (!resolve) return;
    pendingWhiteboardSnapshotRequests.delete(requestId);
    resolve(hasImage);
  }

  function settleAllWhiteboardSnapshotRequests(hasImage: boolean) {
    for (const [requestId, resolve] of Array.from(pendingWhiteboardSnapshotRequests.entries())) {
      pendingWhiteboardSnapshotRequests.delete(requestId);
      resolve(hasImage);
    }
  }

  async function requestFreshWhiteboardSnapshot(reason: string): Promise<boolean> {
    if (browserWs.readyState !== WebSocket.OPEN) return false;

    const requestId = randomUUID();
    return await new Promise<boolean>((resolve) => {
      const timer = setTimeout(() => {
        pendingWhiteboardSnapshotRequests.delete(requestId);
        log.warn(`Whiteboard snapshot request timed out (${reason})`);
        resolve(false);
      }, WHITEBOARD_SNAPSHOT_REQUEST_TIMEOUT_MS);

      pendingWhiteboardSnapshotRequests.set(requestId, (hasImage) => {
        clearTimeout(timer);
        resolve(hasImage);
      });

      browserWs.send(JSON.stringify({
        type: "whiteboard_snapshot_request",
        requestId,
        reason,
      }));
    });
  }

  const sortedQuestions = ctx.questions.sort((a, b) => a.order - b.order);
  const configIsZh = isChineseInterview(ctx);
  let isZh = configIsZh;

  const userLangSamples: string[] = [];
  function updateUserLanguage(text: string) {
    if (!text || text.length < 3) return;
    userLangSamples.push(text);
    if (userLangSamples.length > 5) userLangSamples.shift();

    const combined = userLangSamples.join(" ");
    const cjkChars = (combined.match(/[\u4e00-\u9fff\u3400-\u4dbf]/g) || []).length;
    const totalChars = combined.replace(/\s+/g, "").length;
    if (totalChars === 0) return;

    const cjkRatio = cjkChars / totalChars;
    const detectedZh = cjkRatio > 0.3;
    if (detectedZh !== isZh) {
      isZh = detectedZh;
      log.info(`User language detected: ${detectedZh ? "zh" : "en"} (CJK ratio: ${(cjkRatio * 100).toFixed(0)}%, overriding config=${configIsZh ? "zh" : "en"})`);
    }
  }

  const startIdx = ctx.startQuestionIndex ?? 0;
  if (startIdx > 0 && startIdx < sortedQuestions.length) {
    currentQuestionIndex = startIdx;
  }

  log.info(
    `Interview: "${ctx.title}" (${sortedQuestions.length} questions, lang=${ctx.language}, startQ=${currentQuestionIndex}, followUpDepth=${ctx.followUpDepth})`
  );

  const NEXT_TOKEN = "[NEXT]";
  const PREV_TOKEN = "[PREV]";

  function clearAsrInterimStall() {
    if (asrInterimStallTimer) {
      clearTimeout(asrInterimStallTimer);
      asrInterimStallTimer = null;
    }
    asrInterimStallText = "";
    asrInterimStallChangedAt = 0;
  }

  function clearPendingAsrFinal() {
    clearSemanticDecision();
    if (manualSubmitTimer) { clearTimeout(manualSubmitTimer); manualSubmitTimer = null; }
    if (pendingAsrFinalTimer) {
      clearTimeout(pendingAsrFinalTimer);
      pendingAsrFinalTimer = null;
    }
    clearAsrInterimStall();
    pendingAsrFinalText = "";
    pendingAsrFinalPrefix = "";
    pendingAsrFinalStartedAt = 0;
    pendingAsrFinalLastChangedAt = 0;
    asrRotationRecoveryUntil = 0;
    markAsrSessionCommitted(asrSession);
  }

  /** Combine speech retained across an ASR rotation with the live session's transcript. */
  function pendingTextForSessionUpdate(sessionText: string): string {
    if (!pendingAsrFinalPrefix) return sessionText;
    if (!sessionText) return pendingAsrFinalPrefix;
    return mergeAsrSegments(pendingAsrFinalPrefix, sessionText);
  }

  function clearHeldBargeInInterim() {
    if (heldBargeInInterimTimer) {
      clearTimeout(heldBargeInInterimTimer);
      heldBargeInInterimTimer = null;
    }
    heldBargeInInterimText = "";
    heldBargeInInterimStartedAt = 0;
  }

  function getAsrFinalCoalesceDelay(text: string): number {
    if (ctx.turnTaking === "SEMANTIC") return 180;
    if (ctx.turnTaking === "PATIENT") return 2500;
    const wordCount = text.split(/\s+/).filter(Boolean).length;
    const terminalPunctuation = /[.?!。？！]\s*$/.test(text);
    const looksShortAndComplete =
      wordCount <= 9 &&
      terminalPunctuation &&
      (/[?？]\s*$/.test(text) || /\b(?:yes|yeah|yep|no|okay|ok|hello|hi)\b/i.test(text));

    if (looksShortAndComplete) return ASR_SHORT_FINAL_COALESCE_MS;
    if (wordCount >= 18 || text.length >= 120) return ASR_LONG_FINAL_COALESCE_MS;
    return ASR_FINAL_COALESCE_MS;
  }

  function noteIncomingAudioActivity(pcm: Buffer) {
    if (pcm.length < 2) return;

    let sumSq = 0;
    let samples = 0;
    for (let offset = 0; offset + 1 < pcm.length; offset += 2) {
      const sample = pcm.readInt16LE(offset) / 32768;
      sumSq += sample * sample;
      samples++;
    }
    if (samples === 0) return;

    const rms = Math.sqrt(sumSq / samples);
    if (rms >= ASR_AUDIO_ACTIVITY_RMS_THRESHOLD) {
      lastUserAudioActivityAt = Date.now();
    }
    // Cancel before synthesis, even if live ASR captions have already hidden the thinking UI.
    if (ctx.turnTaking && generatingResponse && !ttsSpeaking && rms >= 0.028) {
      resumedSpeechMs += samples / 16;
      if (resumedSpeechMs >= 600) {
        cancelResponse();
        suppressAsrResults = false;
        if (browserWs.readyState === WebSocket.OPEN) browserWs.send(JSON.stringify({ type: "response_cancelled" }));
      }
    } else {
      resumedSpeechMs = 0;
    }
  }

  function shouldHoldPendingAsrFinalForActiveSpeech(finalText: string): boolean {
    if (!finalText || ASR_ACTIVE_SPEECH_HOLD_MS <= 0) return false;
    const wordCount = finalText.split(/\s+/).filter(Boolean).length;
    if (!ctx.turnTaking && wordCount < 12 && finalText.length < 80) return false;
    if (ctx.turnTaking === "PATIENT" && Date.now() - lastUserAudioActivityAt < 3000) return true;
    const heldForMs = pendingAsrFinalStartedAt ? Date.now() - pendingAsrFinalStartedAt : 0;
    const recentlyChanged =
      pendingAsrFinalLastChangedAt > 0 &&
      Date.now() - pendingAsrFinalLastChangedAt < ASR_PENDING_FINAL_QUIET_MS;
    if (recentlyChanged) return true;

    const micStillActive = Date.now() - lastUserAudioActivityAt < ASR_ACTIVE_SPEECH_HOLD_MS;
    const holdAction = activeSpeechHoldAction({
      micStillActive,
      heldForMs,
      maxHoldMs: ASR_MAX_ACTIVE_SPEECH_HOLD_MS,
      // A reconnect briefly interrupts both the provider transcript and the
      // microphone activity signal. Keep the carried turn open through that gap.
      rotationRecoveryActive: Date.now() < asrRotationRecoveryUntil,
    });
    if (holdAction === "release") return false;

    if (holdAction === "rotate") {
      log.warn(
        `ASR active-speech hold reached ${ASR_MAX_ACTIVE_SPEECH_HOLD_MS}ms; rotating ASR session (keeping pending text)`,
      );
      pendingAsrFinalStartedAt = Date.now();
      rotateAsrSession();
      return true;
    }

    const textStuckMs =
      pendingAsrFinalLastChangedAt > 0
        ? Date.now() - pendingAsrFinalLastChangedAt
        : 0;
    const sinceLastStuckRotation = lastAsrStuckRotationAt > 0
      ? Date.now() - lastAsrStuckRotationAt
      : Infinity;
    if (
      ASR_STUCK_TEXT_ROTATE_MS > 0 &&
      textStuckMs >= ASR_STUCK_TEXT_ROTATE_MS &&
      sinceLastStuckRotation >= ASR_STUCK_TEXT_ROTATE_MS
    ) {
      log.warn(
        `ASR text stuck for ${textStuckMs}ms while mic active; rotating ASR session to recover`,
      );
      lastAsrStuckRotationAt = Date.now();
      rotateAsrSession();
      return true;
    }

    if (
      ASR_SESSION_MAX_CONTINUOUS_SPEECH_MS > 0 &&
      asrSessionFirstSpeechAt > 0 &&
      Date.now() - asrSessionFirstSpeechAt > ASR_SESSION_MAX_CONTINUOUS_SPEECH_MS
    ) {
      log.warn(
        `ASR session continuous speech exceeded ${ASR_SESSION_MAX_CONTINUOUS_SPEECH_MS}ms; rotating ASR session (keeping pending text)`,
      );
      rotateAsrSession();
      return true;
    }

    return true;
  }

  /**
   * Disconnect and reconnect the ASR engine WITHOUT clearing pendingAsrFinalText.
   * Prevents mid-sentence cutoff while refreshing a degraded ASR session.
   */
  function rotateAsrSession() {
    asrRotationPending = true;
    asrRotationRecoveryUntil = Date.now() + ASR_LONG_FINAL_COALESCE_MS;
    asrIntentionalClose = true;
    if (keepAliveInterval) {
      clearInterval(keepAliveInterval);
      keepAliveInterval = null;
    }
    if (asrWs && asrWs.readyState === WebSocket.OPEN && asrAlive) {
      try {
        asrAudioSeq++;
        asrWs.send(buildBigModelAudioRequest(Buffer.alloc(0), asrAudioSeq, true));
      } catch { /* ignore */ }
    }
    if (asrWs) {
      closeDetachedAsrSocket(asrWs);
    }
    asrWs = null;
    asrAlive = false;
    asrSessionFirstSpeechAt = 0;
    // The replacement websocket transcribes only the audio that follows, so what the old
    // session already heard has to be carried forward explicitly.
    pendingAsrFinalPrefix = pendingAsrFinalText;
    connectAsr().catch(log.error);
  }

  function flushHeldBargeInInterim(reason: string) {
    const rawText = heldBargeInInterimText.trim();
    clearHeldBargeInInterim();
    if (ctx.turnTaking === "MANUAL" || ctx.turnTaking === "SEMANTIC") { schedulePendingAsrFinal(rawText, reason); return; }

    if (!rawText || rawText.length < 2 || interviewDone || endingInterview || isTransitioning) return;

    let finalText = collapseInternalAsrRepetitions(rawText);

    const lastUserTurn = [...questionTranscript].reverse().find((e) => e.role === "user");
    if (lastUserTurn) {
      finalText = trimCrossTurnOverlap(lastUserTurn.text, finalText);
      if (!finalText.trim()) return;
    }

    log.info(`ASR barge-in interim promoted (${reason}): "${finalText.slice(0, 80)}"`);
    if (browserWs.readyState === WebSocket.OPEN) {
      browserWs.send(JSON.stringify({ type: "asr_ended", text: finalText }));
    }
    handleUserUtterance(finalText, { allowRecentReplay: true }).catch(log.error);
  }

  function holdBargeInInterim(text: string) {
    const trimmed = text.trim();
    if (trimmed.length < 2) return;
    if (ctx.turnTaking === "MANUAL" || ctx.turnTaking === "SEMANTIC") { schedulePendingAsrFinal(text, "barge-in"); return; }

    heldBargeInInterimText = heldBargeInInterimText
      ? mergeAsrSegments(heldBargeInInterimText, trimmed)
      : trimmed;

    if (heldBargeInInterimTimer) {
      clearTimeout(heldBargeInInterimTimer);
    }
    if (!heldBargeInInterimStartedAt) {
      heldBargeInInterimStartedAt = Date.now();
    }

    // Promoting this as its own turn while the speaker is still going splits one answer across
    // several turns, each drawing its own reply that then gets barged into as well. Wait for the
    // microphone to go quiet, the same way the pending-final path does, but never indefinitely —
    // sustained room noise would otherwise strand the turn.
    const promoteIfSettled = () => {
      heldBargeInInterimTimer = null;
      const heldForMs = Date.now() - heldBargeInInterimStartedAt;
      const holdAction = activeSpeechHoldAction({
        micStillActive:
          Date.now() - lastUserAudioActivityAt < (ctx.turnTaking === "PATIENT" ? 3000 : ASR_ACTIVE_SPEECH_HOLD_MS),
        heldForMs,
        maxHoldMs: ASR_MAX_ACTIVE_SPEECH_HOLD_MS,
      });
      if (holdAction !== "release") {
        if (holdAction === "rotate") {
          log.warn(
            `ASR barge-in interim hold reached ${ASR_MAX_ACTIVE_SPEECH_HOLD_MS}ms; rotating ASR session instead of splitting active speech`,
          );
          heldBargeInInterimStartedAt = Date.now();
          rotateAsrSession();
        }
        heldBargeInInterimTimer = setTimeout(promoteIfSettled, ASR_ACTIVE_SPEECH_HOLD_MS);
        return;
      }
      flushHeldBargeInInterim("no-final-after-barge-in");
    };

    heldBargeInInterimTimer = setTimeout(
      promoteIfSettled,
      getAsrFinalCoalesceDelay(heldBargeInInterimText),
    );
  }

  function sendAsrInterim(text: string) {
    if (browserWs.readyState !== WebSocket.OPEN) return;
    browserWs.send(JSON.stringify({
      type: "asr",
      data: { results: [{ text, definite: false }] },
    }));
  }

  function sendAsrPending(text: string, delayMs: number) {
    if (browserWs.readyState !== WebSocket.OPEN) return;
    browserWs.send(JSON.stringify({
      type: "asr_pending",
      text,
      delayMs,
      manual: ctx.turnTaking === "MANUAL",
      semantic: ctx.turnTaking === "SEMANTIC",
    }));
  }

  function sendAsrCancelled(reason: string) {
    if (browserWs.readyState !== WebSocket.OPEN) return;
    browserWs.send(JSON.stringify({
      type: "asr_cancelled",
      reason,
    }));
  }

  function flushPendingAsrFinal(reason: string, explicitSubmit = false) {
    if (ctx.turnTaking === "MANUAL" && !explicitSubmit) return;
    const rawText = pendingAsrFinalText.trim();
    if (!rawText || rawText.length < 2 || interviewDone || endingInterview || isTransitioning) {
      clearPendingAsrFinal();
      return;
    }

    if (ctx.turnTaking === "SEMANTIC" && !explicitSubmit) {
      primeSemanticDecision(rawText);
      const quietElapsedMs = Math.min(Date.now() - lastUserAudioActivityAt, Date.now() - pendingAsrFinalLastChangedAt);
      const remaining = semanticWaitMs({ decision: semanticResult, resultMatches: semanticResultKey === normalizeUserUtteranceKey(rawText), requestPending: semanticRequestPending, quietMs: quietElapsedMs });
      if (remaining > 0) {
        if (pendingAsrFinalTimer) clearTimeout(pendingAsrFinalTimer);
        pendingAsrFinalTimer = setTimeout(() => flushPendingAsrFinal("semantic decision"), Math.min(300, remaining));
        sendAsrPending(rawText, remaining);
        return;
      }
    }

    if (!explicitSubmit && shouldHoldPendingAsrFinalForActiveSpeech(rawText)) {
      if (pendingAsrFinalTimer) {
        clearTimeout(pendingAsrFinalTimer);
      }
      pendingAsrFinalTimer = setTimeout(() => {
        flushPendingAsrFinal(`${reason}, active speech guard`);
      }, ASR_ACTIVE_SPEECH_HOLD_MS);
      log.info(
        `ASR final held (${reason}, speech not settled): "${rawText.slice(0, 80)}"`,
      );
      return;
    }

    clearPendingAsrFinal();

    let finalText = collapseInternalAsrRepetitions(rawText);

    const lastUserTurn = [...questionTranscript].reverse().find((e) => e.role === "user");
    if (lastUserTurn) {
      finalText = trimCrossTurnOverlap(lastUserTurn.text, finalText);
      if (!finalText.trim()) {
        sendAsrCancelled("cross_turn_overlap");
        return;
      }
    }

    if (
      !explicitSubmit && shouldIgnoreVolcContinuationFragment(
        finalText,
        questionTranscript,
        lastAssistantMessageWallClockMs,
        isZh,
      )
    ) {
      sendAsrCancelled("continuation_fragment");
      return;
    }

    if (isDuplicateUserFinal(finalText)) {
      consecutiveDuplicateSkips++;
      log.info(`ASR FINAL (${reason}) skipped — duplicate of answered turn: "${finalText.slice(0, 72)}..."`);
      sendAsrCancelled("duplicate");
      if (consecutiveDuplicateSkips >= 2) {
        log.warn(`ASR stuck: ${consecutiveDuplicateSkips} consecutive duplicate skips — forcing reconnection`);
        consecutiveDuplicateSkips = 0;
        disconnectAsr();
        connectAsr().catch(log.error);
      }
      return;
    }

    consecutiveDuplicateSkips = 0;
    log.info(`ASR FINAL (${reason}): "${finalText.slice(0, 80)}"`);

    if (browserWs.readyState === WebSocket.OPEN) {
      browserWs.send(JSON.stringify({ type: "asr_ended", text: finalText }));
    }

    handleUserUtterance(finalText).catch(log.error);
  }

  function pendingAsrFinalDelay(text: string): number {
    const fallback = asrPendingFinalDelayMs({
      coalesceTargetMs: getAsrFinalCoalesceDelay(text),
      quietFloorMs: ASR_PENDING_FINAL_QUIET_MS,
      quietElapsedMs: pendingAsrFinalLastChangedAt
        ? Date.now() - pendingAsrFinalLastChangedAt
        : 0,
    });
    return interviewCommitDelay(ctx.turnTaking, fallback, Date.now() - lastUserAudioActivityAt) ?? 0;
  }

  /**
   * Last-resort watch on an interim the provider has not endpointed, for the failure mode where
   * `definite` never arrives at all. It must not act as a second endpointer competing with
   * `end_window_size`: recognized text routinely freezes *mid-speech* while the recognizer is
   * uncertain, so a frozen interim alone does not mean the speaker stopped. Committing on that
   * signal cuts answers in half and, worse, starts the coalesce clock during a pause so the real
   * window is already spent by the time the speaker finishes. Hence both a long timeout and a
   * silent microphone are required, and the coalesce window is served in full afterwards.
   */
  function trackAsrInterimStall(text: string) {
    if (ctx.turnTaking === "MANUAL") return;
    primeSemanticDecision(text);
    if (ASR_INTERIM_STALL_COMMIT_MS <= 0) return;
    const trimmed = text.trim();
    if (trimmed.length < 2) {
      clearAsrInterimStall();
      return;
    }
    if (
      asrInterimStallTimer &&
      normalizeUserUtteranceKey(asrInterimStallText) === normalizeUserUtteranceKey(trimmed)
    ) {
      return;
    }

    if (asrInterimStallTimer) clearTimeout(asrInterimStallTimer);
    asrInterimStallText = trimmed;
    asrInterimStallChangedAt = Date.now();

    const commitIfSettled = () => {
      asrInterimStallTimer = null;
      const stalled = asrInterimStallText.trim();
      if (
        !stalled ||
        pendingAsrFinalText ||
        interviewDone ||
        endingInterview ||
        isTransitioning ||
        suppressAsrResults
      ) {
        return;
      }

      // Still audibly talking: the recognizer is behind, not finished. Keep waiting.
      if (Date.now() - lastUserAudioActivityAt < ASR_ACTIVE_SPEECH_HOLD_MS) {
        asrInterimStallTimer = setTimeout(commitIfSettled, ASR_ACTIVE_SPEECH_HOLD_MS);
        return;
      }

      log.warn(
        `ASR interim stalled ${Date.now() - asrInterimStallChangedAt}ms without a definite while the mic was quiet — endpointing locally`,
      );
      schedulePendingAsrFinal(stalled, "interim stall");
    };

    asrInterimStallTimer = setTimeout(commitIfSettled, ASR_INTERIM_STALL_COMMIT_MS);
  }

  function schedulePendingAsrFinal(text: string, reason: string) {
    const prev = pendingAsrFinalText;
    const unchanged =
      !!prev &&
      normalizeUserUtteranceKey(prev) === normalizeUserUtteranceKey(text);

    if (unchanged && pendingAsrFinalTimer) {
      log.debug(`ASR duplicate definite while pending: "${text.slice(0, 80)}"`);
      return;
    }

    pendingAsrFinalText = text;
    pendingAsrFinalLastChangedAt = Date.now();
    if (!pendingAsrFinalStartedAt) {
      pendingAsrFinalStartedAt = pendingAsrFinalLastChangedAt;
    }
    sendAsrInterim(text);
    primeSemanticDecision(text);

    if (pendingAsrFinalTimer) {
      clearTimeout(pendingAsrFinalTimer);
    }
    if (ctx.turnTaking === "MANUAL") {
      pendingAsrFinalTimer = null;
      sendAsrPending(text, 0);
      return;
    }
    const delay = pendingAsrFinalDelay(text);
    pendingAsrFinalTimer = setTimeout(() => {
      flushPendingAsrFinal("coalesced");
    }, delay);
    sendAsrPending(text, delay);

    log.info(
      `ASR final pending (${reason}, ${delay}ms): "${text.slice(0, 80)}"`,
    );
  }

  // ── TTS helpers ────────────────────────────────────────────────

  function cancelTts() {
    playbackEchoGuard.finish(Date.now());
    if (ttsAbortController) {
      ttsAbortController.abort();
      ttsAbortController = null;
    }
    ttsSpeaking = false;
  }

  /**
   * Speak text via TTS 2.0 API, streaming audio chunks to the browser.
   * Returns true if TTS completed without cancellation.
   */
  async function speakText(text: string): Promise<boolean> {
    if (sessionPaused || interviewDone || browserWs.readyState !== WebSocket.OPEN) return false;
    cancelTts();

    const abortController = new AbortController();
    const utteranceId = randomUUID();
    ttsAbortController = abortController;
    ttsSpeaking = true;
    currentSpeech = text;
    playbackEchoGuard.start(text, Date.now());
    if (protectPlayback) {
      // Preserve a genuine continuation captured during model thinking, before any output.
      if (playbackEchoGuard.isEcho(pendingUserUtteranceWhileSuppressed, Date.now())) {
        pendingUserUtteranceWhileSuppressed = "";
      }
      clearHeldBargeInInterim();
      clearPendingAsrFinal();
    }

    const latestAnswer = questionTranscript.findLast(entry => entry.role === "user")?.text || "";
    const ttsOpts = getTtsOptions(ctx.language, ctx, latestAnswer);
    const auth = getTtsAuth();

    // Interrupt any residual browser-side playback and notify TTS starting
    if (browserWs.readyState === WebSocket.OPEN) {
      browserWs.send(JSON.stringify({ type: "interrupt" }));
    }

    let completed = false;
    let totalAudioBytes = 0;
    let firstAudioSentAtMs = 0;
    let sentTranscriptText = false;
    const sendTranscriptTextOnce = () => {
      if (sentTranscriptText || browserWs.readyState !== WebSocket.OPEN) return;
      sentTranscriptText = true;
      browserWs.send(JSON.stringify({
        type: "tts_text",
        data: { text, utteranceId },
      }));
    };
    try {
      for await (const event of synthesizeSpeech(text, auth, ttsOpts, abortController.signal)) {
        if (abortController.signal.aborted) break;
        if (browserWs.readyState !== WebSocket.OPEN) break;

        if (event.type === "audio" && event.audio) {
          sendTranscriptTextOnce();
          browserWs.send(event.audio, { binary: true });
          if (!firstAudioSentAtMs) firstAudioSentAtMs = Date.now();
          totalAudioBytes += event.audio.length;
        } else if (event.type === "sentence_start") {
          // The full response text is sent once the first audio chunk is ready.
        } else if (event.type === "sentence_end") {
          browserWs.send(JSON.stringify({ type: "tts_sentence_end", data: { text: event.text } }));
        } else if (event.type === "error") {
          log.error(`TTS error: ${event.error}`);
          break;
        } else if (event.type === "done") {
          completed = true;
        }
      }
    } catch (err) {
      if (!abortController.signal.aborted) {
        log.error("TTS streaming error:", err);
      }
    }

    if (!completed && !abortController.signal.aborted && browserWs.readyState === WebSocket.OPEN) {
      // Release the browser's output gate even if synthesis stops without a final packet.
      browserWs.send(JSON.stringify({ type: "tts_ended", utteranceId, completed: false }));
    }

    if (completed && !abortController.signal.aborted && browserWs.readyState === WebSocket.OPEN) {
      sendTranscriptTextOnce();
      const elapsedSinceFirstAudioMs = firstAudioSentAtMs
        ? Date.now() - firstAudioSentAtMs
        : 0;
      const fallbackMs = playbackAckFallbackMs(
        totalAudioBytes,
        elapsedSinceFirstAudioMs,
      );

      await new Promise<void>((resolve) => {
        let settled = false;
        const finish = () => {
          if (settled) return;
          settled = true;
          clearTimeout(fallbackTimer);
          abortController.signal.removeEventListener("abort", finish);
          if (pendingPlaybackAck?.utteranceId === utteranceId) {
            pendingPlaybackAck = null;
          }
          resolve();
        };
        const fallbackTimer = setTimeout(() => {
          log.warn(
            `Browser playback acknowledgement timed out after ${fallbackMs}ms (${utteranceId})`,
          );
          finish();
        }, fallbackMs);

        pendingPlaybackAck = { utteranceId, complete: finish };
        abortController.signal.addEventListener("abort", finish, { once: true });
        browserWs.send(JSON.stringify({ type: "tts_ended", utteranceId }));
      });
    }

    if (ttsAbortController === abortController) {
      playbackEchoGuard.finish(Date.now());
      ttsSpeaking = false;
      currentSpeech = "";
      ttsAbortController = null;
    }

    return completed && !abortController.signal.aborted;
  }

  /**
   * Speak text and handle post-TTS actions (transitions, farewell, etc).
   * This replaces the old S2S SayHello + TTS_ENDED event handling.
   */
  async function speakAndHandle(text: string, options?: {
    trackInTranscript?: boolean;
    pendingTransition?: boolean;
    pendingPrevTransition?: boolean;
    pendingFarewell?: boolean;
    pendingFinalTimeout?: boolean;
  }): Promise<void> {
    currentSpeechActions = options;
    const completed = await speakText(text);
    if (!completed || sessionPaused || interviewDone) return;

    if (options?.trackInTranscript !== false) {
      questionTranscript.push({ role: "assistant", text });
      lastAssistantMessageWallClockMs = Date.now();
    }

    // Post-TTS actions
    if (options?.pendingFarewell) {
      endInterview();
      return;
    }

    if (options?.pendingFinalTimeout && ctx.turnTaking !== "MANUAL") {
      finalResponseTimeout = setTimeout(() => {
        if (!interviewDone && !awaitingFinalResponse) return;
        awaitingFinalResponse = false;
        if (finalResponseTimeout) {
          clearTimeout(finalResponseTimeout);
          finalResponseTimeout = null;
        }
        const farewell = buildFarewellSayHello(isZh);
        log.info("No final response after timeout, sending farewell");
        speakAndHandle(farewell, { pendingFarewell: true }).catch(log.error);
      }, 15_000);
    }

    if (options?.pendingTransition && !isTransitioning && !interviewDone) {
      const isLastQuestion = currentQuestionIndex >= sortedQuestions.length - 1;
      if (isLastQuestion) {
        if (ctx.turnTaking === "MANUAL") return;
        log.info("TTS ended on last Q — waiting 15s for user response before wrap-up");
        pendingLastQuestionTimeout = setTimeout(() => {
          pendingLastQuestionTimeout = null;
          if (ctx.turnTaking && (pendingAsrFinalText || Date.now() - lastUserAudioActivityAt < 3000)) return;
          if (!isTransitioning && !interviewDone && !generatingResponse) {
            log.info("No user response on last Q — auto-wrapping up");
            handleTransition(true).catch(log.error);
          }
        }, 15_000);
      } else {
        log.info("TTS ended — triggering queued transition");
        handleTransition(true).catch(log.error);
      }
    }

    if (options?.pendingPrevTransition && !isTransitioning && !interviewDone && currentQuestionIndex > 0) {
      log.info("TTS ended — queuing PREV transition after audio flush delay");
      setTimeout(() => {
        handlePreviousTransition(true).catch(log.error);
      }, 1500);
    }
  }

  // ── Interview lifecycle ────────────────────────────────────────

  function endInterview() {
    if (interviewDone) return;
    interviewDone = true;
    cancelResponse();
    clearPendingAsrFinal();
    awaitingFinalResponse = false;
    cancelTts();
    if (finalResponseTimeout) {
      clearTimeout(finalResponseTimeout);
      finalResponseTimeout = null;
    }
    if (pendingLastQuestionTimeout) {
      clearTimeout(pendingLastQuestionTimeout);
      pendingLastQuestionTimeout = null;
    }
    browserWs.send(JSON.stringify({ type: "interview_complete" }));
    log.info("Interview complete signal sent");
  }

  function queueFarewellAndEnd(reason: string) {
    if (interviewDone || endingInterview) return;
    endingInterview = true;
    cancelResponse();

    awaitingFinalResponse = false;
    generatingResponse = false;
    clearPendingAsrFinal();
    cancelTts();

    if (finalResponseTimeout) {
      clearTimeout(finalResponseTimeout);
      finalResponseTimeout = null;
    }
    if (pendingLastQuestionTimeout) {
      clearTimeout(pendingLastQuestionTimeout);
      pendingLastQuestionTimeout = null;
    }

    // Summarizing is best-effort: `endingInterview` is already latched, so
    // throwing here would leave the participant with no farewell and the client
    // with no `interview_complete` — the session would hang as IN_PROGRESS.
    try {
      const summaryTarget = questionAwaitingSummary(
        sortedQuestions,
        currentQuestionIndex,
        questionTranscript.length,
      );
      if (summaryTarget) {
        const transcriptSnapshot = [...questionTranscript];
        summarizeQuestion(summaryTarget.text, transcriptSnapshot, isZh)
          .then((summary) => questionSummaries.push(summary))
          .catch(log.error);
      }
    } catch (err) {
      log.error("Failed to summarize the final question:", err);
    }

    const farewell = buildFarewellSayHello(isZh);
    log.info(reason);

    speakAndHandle(farewell, { pendingFarewell: true }).catch((err) => {
      log.error("Farewell TTS failed:", err);
      endInterview();
    });

    // Safety net
    setTimeout(() => {
      if (!interviewDone) {
        log.warn("Farewell TTS timed out after 10s — forcing interview end");
        endInterview();
      }
    }, 10_000);
  }

  // ── LLM-controlled response generator ─────────────────────────

  async function buildAgentContext(): Promise<AgentContext> {
    const previousContext = questionSummaries
      .map((s, i) => `Q${i + 1} (${sortedQuestions[i]?.text.slice(0, 50)}): ${s}`)
      .slice(ctx.interviewStyle === "STORY" ? -3 : 0)
      .join("\n");

    const currentQ = sortedQuestions[currentQuestionIndex];
    const agentCtx: AgentContext = { memory: previousContext };

    if (currentQ.type === "CODING" && currentCodeContent) {
      agentCtx.codeContent = currentCodeContent;
      agentCtx.codeLanguage = currentCodeLanguage;
    }

    if (currentQ.type === "WHITEBOARD") {
      await requestFreshWhiteboardSnapshot("agent_context");

      if (whiteboardDirty && latestWhiteboardImage) {
        log.info(`Whiteboard vision: calling vision LLM (inline wait ${WHITEBOARD_VISION_INLINE_TIMEOUT_MS}ms)`);
        const visionPromise = describeWhiteboard(latestWhiteboardImage, isZh);
        const result = await Promise.race([
          visionPromise.then((desc) => ({ desc, timedOut: false })),
          new Promise<{ desc: string; timedOut: boolean }>((resolve) =>
            setTimeout(() => resolve({ desc: "", timedOut: true }), WHITEBOARD_VISION_INLINE_TIMEOUT_MS)
          ),
        ]);
        if (!result.timedOut && result.desc) {
          cachedWhiteboardDescription = result.desc;
          whiteboardDirty = false;
          log.info(`Whiteboard vision: description ready (${result.desc.length} chars)`);
        } else if (result.timedOut) {
          agentCtx.whiteboardLoading = true;
          pendingWhiteboardVision = true;
          log.info("Whiteboard vision: still running; deferring to two-phase follow-up");
          visionPromise.then((desc) => {
            if (desc) {
              cachedWhiteboardDescription = desc;
              whiteboardDirty = false;
              log.info(`Whiteboard vision: background description ready (${desc.length} chars)`);
            }
            pendingWhiteboardVision = false;
          }).catch(() => { pendingWhiteboardVision = false; });
        } else if (!result.timedOut && !result.desc) {
          agentCtx.whiteboardLoading = true;
          log.info("Whiteboard vision: returned empty (likely API error), treating as loading");
        }
      } else if (!latestWhiteboardImage) {
        log.info("Whiteboard: no image received from frontend yet");
      }

      if (cachedWhiteboardDescription) {
        agentCtx.whiteboardDescription = cachedWhiteboardDescription;
      }
    }

    if (lastResponseWasCorrection) {
      agentCtx.correctionGuard = isZh
        ? "\n**重要：你上一条回复要求受访者重新考虑或修改答案。他们还没有回应你的纠正。等待他们的回答，绝对不要加 [NEXT]。**\n"
        : "\n**IMPORTANT: Your last response asked the participant to reconsider or revise their answer. They have NOT yet responded to your correction. Wait for their answer. Do NOT add [NEXT] under any circumstances.**\n";
    }

    if (recentAgentResponses.length >= 2) {
      const last = recentAgentResponses[recentAgentResponses.length - 1];
      const prev = recentAgentResponses[recentAgentResponses.length - 2];
      if (last && prev && isSimilarResponse(last, prev)) {
        agentCtx.antiRepetition = isZh
          ? `\n**重要：你上面的回复已经重复了（"${last.slice(0, 40)}..."）。你必须用完全不同的方式回应。仔细阅读受访者最后一句话，如果他们在问你问题，请直接回答。不要再说类似的话。不要像结束整场访谈那样告别（除非当前已是最后一题且流程要求收尾）。**\n`
          : `\n**IMPORTANT: Your previous responses have been repetitive ("${last.slice(0, 40)}..."). You MUST respond differently. Read the participant's last message carefully — if they are asking you a question, answer it directly. Do NOT repeat similar phrasing. Do NOT speak as if the entire interview is ending (unless this is truly the final wrap-up for the last question).**\n`;
        log.info("Anti-repetition guard activated");
      }
    }

    return agentCtx;
  }

  function getMaxTokensForQuestion(type: string): number {
    switch (type) {
      case "CODING":
      case "WHITEBOARD":
      case "RESEARCH":
        return 250;
      case "SINGLE_CHOICE":
      case "MULTIPLE_CHOICE":
        return 200;
      default:
        return 150;
    }
  }

  async function generateControlledResponse(opts?: { forceSkip?: boolean; signal?: AbortSignal }): Promise<string> {
    const forceSkip = opts?.forceSkip ?? false;
    const currentQ = sortedQuestions[currentQuestionIndex];
    const history = PROMPTS.formatHistory(questionTranscript, isZh);
    const agentCtx = await buildAgentContext();
    const latestAnsweredExchange = getLatestAnsweredExchange();

    const qOpts = currentQ.options as { options: string[]; allowMultiple?: boolean } | null | undefined;
    let choiceInstruction = "";
    if (currentQ.type === "SINGLE_CHOICE" && qOpts?.options?.length) {
      const labels = qOpts.options.map((o, i) => `${String.fromCharCode(65 + i)}. ${o}`).join(", ");
      choiceInstruction = bt(isZh, PROMPTS.choiceInstruction.singleChoice(labels));
    } else if (currentQ.type === "MULTIPLE_CHOICE" && qOpts?.options?.length) {
      const labels = qOpts.options.map((o, i) => `${String.fromCharCode(65 + i)}. ${o}`).join(", ");
      choiceInstruction = bt(isZh, PROMPTS.choiceInstruction.multipleChoice(labels));
    } else if (currentQ.type === "CODING") {
      choiceInstruction = bt(isZh, PROMPTS.choiceInstruction.coding(NEXT_TOKEN, PREV_TOKEN));
    } else if (currentQ.type === "WHITEBOARD") {
      choiceInstruction = bt(isZh, PROMPTS.choiceInstruction.whiteboard(NEXT_TOKEN, PREV_TOKEN));
    } else if (currentQ.type === "RESEARCH") {
      choiceInstruction = bt(isZh, PROMPTS.choiceInstruction.research(NEXT_TOKEN, PREV_TOKEN));
    }

    const effectiveMaxFollowUps = ctx.interviewStyle === "STORY" && /当前环节：(00|收尾)/.test(currentQ.description || "")
      ? 1 : maxFollowUpsForDepth(ctx.followUpDepth, currentQ.type);
    const followUpsDone = countFollowUpsSpent({
      transcript: questionTranscript,
      userTurns: userTurnsOnCurrentQ,
    });
    const turnsLeft = effectiveMaxFollowUps - followUpsDone;
    const hasAnswered = hasAnsweredCurrentQuestion({
      transcript: questionTranscript,
      userTurns: userTurnsOnCurrentQ,
      isZh,
    });
    let followUpInstruction: string;
    const isCodingOrWhiteboard = currentQ.type === "CODING" || currentQ.type === "WHITEBOARD";

    const followBudgetCtx = {
      isLastQuestion: currentQuestionIndex >= sortedQuestions.length - 1,
    };

    if (forceSkip) {
      followUpInstruction = bt(isZh, PROMPTS.followUp.skipOverride(NEXT_TOKEN, followBudgetCtx));
      choiceInstruction = "";
    } else if (lastResponseWasCorrection) {
      followUpInstruction = isZh
        ? `等待受访者回应你的纠正。不要加 ${NEXT_TOKEN}。`
        : `Wait for the participant to respond to your correction. Do NOT add ${NEXT_TOKEN}.`;
    } else if (isCodingOrWhiteboard) {
      followUpInstruction = bt(isZh, PROMPTS.followUp.codingWb(NEXT_TOKEN));
    } else if (turnsLeft <= 0 && !hasAnswered) {
      followUpInstruction = bt(isZh, PROMPTS.followUp.awaitingAnswer(NEXT_TOKEN));
    } else if (turnsLeft <= -1) {
      followUpInstruction = bt(isZh, PROMPTS.followUp.pastLimit(NEXT_TOKEN, followBudgetCtx));
    } else if (turnsLeft <= 0) {
      followUpInstruction = bt(isZh, PROMPTS.followUp.atLimit(NEXT_TOKEN, followBudgetCtx));
    } else if (turnsLeft === 1) {
      followUpInstruction = bt(isZh, PROMPTS.followUp.oneLeft(NEXT_TOKEN, followBudgetCtx));
    } else {
      followUpInstruction = bt(isZh, PROMPTS.followUp.remaining(turnsLeft, NEXT_TOKEN, followBudgetCtx));
    }
    const mustAdvanceForFollowUpLimit =
      !forceSkip &&
      !lastResponseWasCorrection &&
      !isCodingOrWhiteboard &&
      hasAnswered &&
      turnsLeft <= 0;

    const promptParams = {
      aiName: ctx.aiName,
      title: ctx.title,
      qNum: currentQuestionIndex + 1,
      totalQs: sortedQuestions.length,
      qText: currentQ.text,
      qDescription: currentQ.description,
      qType: currentQ.type,
      choiceInstruction,
      history,
      followUpInstruction,
      nextToken: NEXT_TOKEN,
      prevToken: PREV_TOKEN,
      userTurns: userTurnsOnCurrentQ,
      previousContext: agentCtx.memory || undefined,
      codeContent: agentCtx.codeContent,
      codeLanguage: agentCtx.codeLanguage,
      whiteboardDescription: agentCtx.whiteboardDescription,
      whiteboardLoading: agentCtx.whiteboardLoading,
      correctionGuard: agentCtx.correctionGuard,
      antiRepetition: agentCtx.antiRepetition,
      recentInterviewerResponses: recentAgentResponses.slice(-3),
      latestInterviewerPrompt: latestAnsweredExchange?.interviewer,
      latestParticipantAnswer: latestAnsweredExchange?.participant,
      forceLanguage: userLangSamples.length > 0 ? (isZh ? "zh" : "en") : undefined,
      isLastQuestion: followBudgetCtx.isLastQuestion,
      interviewStyle: ctx.interviewStyle,
    };

    const prompt = bt(isZh, isCodingOrWhiteboard
      ? PROMPTS.response.codingWb(promptParams)
      : PROMPTS.response.normal(promptParams));

    const maxTokens = getMaxTokensForQuestion(currentQ.type);
    const startMs = Date.now();
    const responseQuestionIndex = currentQuestionIndex;
    const responseGeneration = transitionGeneration;
    let response = await callRelayLLM(prompt, maxTokens, ctx.interviewStyle === "STORY" ? text => {
      if (opts?.signal?.aborted || interviewDone || isTransitioning || currentQuestionIndex !== responseQuestionIndex || transitionGeneration !== responseGeneration || browserWs.readyState !== WebSocket.OPEN) return;
      const visible = text.replace(/\[(?:NEXT|PREV)\]/g, "").replace(/\[[A-Z]*$/, "").trim();
      browserWs.send(JSON.stringify({ type: "response_delta", data: { text: visible } }));
    } : undefined, opts?.signal);
    if (interviewDone || isTransitioning || currentQuestionIndex !== responseQuestionIndex || transitionGeneration !== responseGeneration) return "";

    response = response.replace(/^(追问型|结束型|FOLLOW[- ]?UP|WRAP[- ]?UP)\s*[:：]\s*/i, "").trim();

    const turnBudgetFinalized = finalizeTurnBudgetResponse({
      response,
      nextToken: NEXT_TOKEN,
      mustAdvance: mustAdvanceForFollowUpLimit,
      keepsConversationOpen: replyKeepsConversationOpen(
        response.replace(NEXT_TOKEN, "").replace(PREV_TOKEN, "").trim(),
        isZh,
      ),
      transitionResponse: isZh ? "好的，谢谢你的分享。" : "Thanks for sharing.",
    });
    if (turnBudgetFinalized.changed) {
      log.info("Forced [NEXT] — follow-up limit reached");
      response = turnBudgetFinalized.response;
    }

    if (!forceSkip) {
      if (
        !mustAdvanceForFollowUpLimit &&
        response.includes(NEXT_TOKEN) &&
        replyKeepsConversationOpen(response.replace(NEXT_TOKEN, ""), isZh)
      ) {
        log.info("Stripped [NEXT] — response still invites a participant reply");
        response = response.replace(NEXT_TOKEN, "").trim();
      }

      if (response.includes(NEXT_TOKEN) && userTurnsOnCurrentQ === 0) {
        log.info("Stripped [NEXT] — no user response on this question yet");
        response = response.replace(NEXT_TOKEN, "").trim();
      }

      if (response.includes(NEXT_TOKEN) && lastResponseWasCorrection) {
        log.info("Stripped [NEXT] — awaiting response to correction");
        response = response.replace(NEXT_TOKEN, "").trim();
      }
    }

    if (forceSkip && !response.includes(NEXT_TOKEN)) {
      log.info("Force-adding [NEXT] — user explicitly asked to skip");
      response = response.trimEnd() + " " + NEXT_TOKEN;
    }

    lastResponseWasCorrection = isCorrection(response, isZh);
    if (lastResponseWasCorrection) {
      log.info("Response detected as correction — will guard next turn");
    }

    const spokenResponse = response.replace(NEXT_TOKEN, "").replace(PREV_TOKEN, "").trim();
    if (spokenResponse) {
      recentAgentResponses.push(spokenResponse);
      if (recentAgentResponses.length > 5) recentAgentResponses.shift();
    }

    log.info(`Response LLM (${Date.now() - startMs}ms, ${maxTokens}tok, turn ${userTurnsOnCurrentQ}, follow-ups ${followUpsDone}/${effectiveMaxFollowUps}): "${response.slice(0, 100)}..."`);
    return response;
  }

  // ── Two-phase whiteboard follow-up ─────────────────────────────

  function scheduleWhiteboardFollowUp() {
    const pollInterval = 300;
    const maxWait = WHITEBOARD_VISION_FOLLOW_UP_MAX_WAIT_MS;
    let waited = 0;

    const poll = () => {
      if (isTransitioning || interviewDone || browserWs.readyState !== WebSocket.OPEN) return;

      if (!pendingWhiteboardVision && cachedWhiteboardDescription) {
        log.info("Whiteboard vision ready — sending follow-up response");
        generatingResponse = true;
        generateControlledResponse()
          .then((followUp) => {
            generatingResponse = false;
            if (!followUp || browserWs.readyState !== WebSocket.OPEN) return;
            const spokenFollowUp = followUp.replace(NEXT_TOKEN, "").replace(PREV_TOKEN, "").trim();
            if (spokenFollowUp) {
              log.info("Sent whiteboard follow-up via TTS");
              speakAndHandle(spokenFollowUp).catch(log.error);
            }
          })
          .catch((err) => {
            log.error("Whiteboard follow-up failed:", err);
            generatingResponse = false;
          });
        return;
      }

      waited += pollInterval;
      if (waited < maxWait) {
        setTimeout(poll, pollInterval);
      } else {
        log.info("Whiteboard vision timed out — no follow-up sent");
      }
    };

    setTimeout(poll, pollInterval);
  }

  // ── Transition handler ──────────────────────────────────────────

  function sendTransitionCancelled(direction: "next" | "previous") {
    if (browserWs.readyState !== WebSocket.OPEN) return;
    browserWs.send(JSON.stringify({
      type: "transition_cancelled",
      direction,
      questionIndex: currentQuestionIndex,
      totalQuestions: sortedQuestions.length,
    }));
  }

  function queueManualTransition(direction: "next" | "previous") {
    pendingManualTransitionDirection = direction;
    cancelTts();
    if (browserWs.readyState === WebSocket.OPEN) {
      browserWs.send(JSON.stringify({ type: "transitioning", auto: false, direction }));
    }
    log.info(`Manual ${direction} requested during active transition — queued`);
  }

  function runQueuedManualTransition(): boolean {
    const direction = pendingManualTransitionDirection;
    if (!direction || interviewDone) return false;

    pendingManualTransitionDirection = null;
    isTransitioning = false;

    if (direction === "previous") {
      handlePreviousTransition(false).catch(log.error);
    } else {
      handleTransition(false).catch(log.error);
    }
    return true;
  }

  async function handleTransition(auto = false) {
    if (interviewDone || sessionPaused) return;
    if (isTransitioning) {
      if (!auto) queueManualTransition("next");
      return;
    }
    // Past the last question the index already sits one beyond the end while the
    // wrap-up is answered. There is nothing to advance to, and incrementing
    // again would walk further out of bounds.
    if (currentQuestionIndex >= sortedQuestions.length) {
      queueFarewellAndEnd("Advance requested after the final question");
      return;
    }
    const transitionId = ++transitionGeneration;
    isTransitioning = true;
    cancelResponse();
    clearPendingAsrFinal();

    suppressAsrResults = true;
    disconnectAsr();
    cancelTts();
    generatingResponse = false;

    try {
      browserWs.send(JSON.stringify({ type: "transitioning", auto, direction: "next" }));

      const currentQ = sortedQuestions[currentQuestionIndex];
      const transcriptSnapshot = [...questionTranscript];
      questionTranscript = [];
      userTurnsOnCurrentQ = 0;
      lastResponseWasCorrection = false;
      cachedWhiteboardDescription = "";
      whiteboardDirty = !!latestWhiteboardImage;
      recentAgentResponses.length = 0;
      if (pendingLastQuestionTimeout) {
        clearTimeout(pendingLastQuestionTimeout);
        pendingLastQuestionTimeout = null;
      }

      currentQuestionIndex++;

      if (currentQuestionIndex < sortedQuestions.length) {
        const summary = transcriptSnapshot.length > 0
          ? await summarizeQuestion(currentQ.text, transcriptSnapshot, isZh)
          : "";
        questionSummaries.push(summary);
        if (sessionPaused || interviewDone || transitionGeneration !== transitionId) return;

        const nextQ = sortedQuestions[currentQuestionIndex];
        const transition = buildTransitionSayHello(currentQuestionIndex, nextQ, isZh);

        browserWs.send(
          JSON.stringify({
            type: "question_change",
            questionIndex: currentQuestionIndex,
            totalQuestions: sortedQuestions.length,
            auto,
          })
        );

        log.info(`→ Q${currentQuestionIndex + 1}/${sortedQuestions.length}: ${nextQ.text.slice(0, 60)}...`);

        await speakAndHandle(transition, { trackInTranscript: false });
      } else {
        if (transcriptSnapshot.length > 0) {
          const lastSummary = await summarizeQuestion(currentQ.text, transcriptSnapshot, isZh);
          questionSummaries.push(lastSummary);
        }
        if (sessionPaused || interviewDone || transitionGeneration !== transitionId) return;

        if (auto) {
          await new Promise(resolve => setTimeout(resolve, 2000));
          if (interviewDone || sessionPaused || transitionGeneration !== transitionId) return;
        }

        awaitingFinalResponse = true;
        const wrapUp = buildWrapUpSayHello(isZh);

        log.info("All questions covered, awaiting final response");
        await speakAndHandle(wrapUp, { pendingFinalTimeout: true });
      }
    } catch (err) {
      log.error("Transition error:", err);
    } finally {
      if (transitionGeneration !== transitionId) return;
      if (runQueuedManualTransition()) return;
      isTransitioning = false;
      if (!interviewDone && browserWs.readyState === WebSocket.OPEN) {
        reopenAsr().catch(log.error);
      }
    }
  }

  // ── Previous-question transition handler ───────────────────────

  async function handlePreviousTransition(auto = false) {
    if (interviewDone || sessionPaused) return;
    if (currentQuestionIndex <= 0) {
      if (!auto) sendTransitionCancelled("previous");
      return;
    }
    if (isTransitioning) {
      if (!auto) queueManualTransition("previous");
      return;
    }
    const transitionId = ++transitionGeneration;
    isTransitioning = true;
    cancelResponse();
    clearPendingAsrFinal();

    suppressAsrResults = true;
    disconnectAsr();
    cancelTts();
    generatingResponse = false;

    try {
      browserWs.send(JSON.stringify({ type: "transitioning", auto, direction: "previous" }));

      const transcriptSnapshot = [...questionTranscript];
      questionTranscript = [];
      userTurnsOnCurrentQ = 0;
      lastResponseWasCorrection = false;
      cachedWhiteboardDescription = "";
      whiteboardDirty = !!latestWhiteboardImage;
      recentAgentResponses.length = 0;
      if (pendingLastQuestionTimeout) {
        clearTimeout(pendingLastQuestionTimeout);
        pendingLastQuestionTimeout = null;
      }

      // Absent when going back from the wrap-up window, where the transcript is
      // the closing exchange rather than an answer to a scripted question.
      const summaryTarget = questionAwaitingSummary(
        sortedQuestions,
        currentQuestionIndex,
        transcriptSnapshot.length,
      );
      if (summaryTarget) {
        const summary = await summarizeQuestion(summaryTarget.text, transcriptSnapshot, isZh);
        questionSummaries.push(summary);
      }

      if (sessionPaused || interviewDone || transitionGeneration !== transitionId) return;
      currentQuestionIndex--;

      const prevQ = sortedQuestions[currentQuestionIndex];
      const transition = buildReturnSayHello(currentQuestionIndex, prevQ, isZh);

      browserWs.send(
        JSON.stringify({
          type: "question_change",
          questionIndex: currentQuestionIndex,
          totalQuestions: sortedQuestions.length,
          auto: false,
        })
      );

      log.info(`← Q${currentQuestionIndex + 1}/${sortedQuestions.length} (back): ${prevQ.text.slice(0, 60)}...`);

      await speakAndHandle(transition, { trackInTranscript: false });
    } catch (err) {
      log.error("Previous transition error:", err);
    } finally {
      if (transitionGeneration !== transitionId) return;
      if (runQueuedManualTransition()) return;
      isTransitioning = false;
      if (!interviewDone && browserWs.readyState === WebSocket.OPEN) {
        reopenAsr().catch(log.error);
      }
    }
  }

  // ── Handle completed user utterance ────────────────────────────

  function normalizeUserUtteranceKey(text: string): string {
    return text.replace(/\s+/g, " ").trim().toLowerCase();
  }

  /**
   * Volcengine sometimes emits a second definite for the same utterance while ASR results are
   * suppressed (or two finals race before generatingResponse is set). If we already stored this
   * user line and an assistant reply followed, skip — otherwise the flush/queue paths call
   * handleUserUtterance again and the agent speaks twice.
   */
  function isDuplicateUserFinal(userText: string): boolean {
    const key = normalizeUserUtteranceKey(userText);
    if (!key) return false;

    let lastUserIdx = -1;
    for (let i = questionTranscript.length - 1; i >= 0; i--) {
      if (questionTranscript[i].role === "user") {
        lastUserIdx = i;
        break;
      }
    }
    if (lastUserIdx >= 0 && lastUserIdx !== questionTranscript.length - 1) {
      const hasAssistantAfter = questionTranscript.slice(lastUserIdx + 1).some(e => e.role === "assistant");

      if (hasAssistantAfter) {
        const lastUserText = questionTranscript[lastUserIdx].text;
        if (shouldSuppressAnsweredAsrFinal(lastUserText, userText)) {
          const merged = mergeAsrSegments(lastUserText, userText);
          if (normalizeUserUtteranceKey(merged).length > normalizeUserUtteranceKey(lastUserText).length) {
            questionTranscript[lastUserIdx] = { role: "user", text: merged };
            rememberAcceptedUserFinal(merged);
          }
          return true;
        }
      }
    }

    return shouldSuppressRecentUserFinalReplay(userText);
  }

  function isReplayOfPendingUserTurn(userText: string): boolean {
    const lastEntry = questionTranscript[questionTranscript.length - 1];
    if (lastEntry?.role !== "user") return false;
    if (!isAsrRollingRevision(lastEntry.text, userText)) return false;

    const merged = mergeAsrSegments(lastEntry.text, userText);
    if (normalizeUserUtteranceKey(merged).length > normalizeUserUtteranceKey(lastEntry.text).length) {
      questionTranscript[questionTranscript.length - 1] = { role: "user", text: merged };
      rememberAcceptedUserFinal(merged);
    }
    return true;
  }

  function isSameAsPendingUserTurn(userText: string): boolean {
    const lastEntry = questionTranscript[questionTranscript.length - 1];
    return (
      lastEntry?.role === "user" &&
      normalizeUserUtteranceKey(lastEntry.text) === normalizeUserUtteranceKey(userText)
    );
  }

  function shouldIgnoreAsrInterimReplay(userText: string): boolean {
    return isDuplicateUserFinal(userText);
  }

  function getLatestAnsweredExchange(): { interviewer: string; participant: string } | null {
    const lastEntry = questionTranscript[questionTranscript.length - 1];
    if (lastEntry?.role !== "user") return null;

    for (let i = questionTranscript.length - 2; i >= 0; i--) {
      const entry = questionTranscript[i];
      if (entry.role === "assistant" && entry.text.trim()) {
        return {
          interviewer: entry.text.trim(),
          participant: lastEntry.text.trim(),
        };
      }
    }

    return null;
  }

  async function handleUserUtterance(
    userText: string,
    options?: { allowRecentReplay?: boolean },
  ) {
    if (!userText || isTransitioning || interviewDone || sessionPaused) return;

    // Fast-path commands work even during TTS/response generation
    if (isUserEndRequest(userText)) {
      queueFarewellAndEnd(`Explicit interview end request: "${userText.slice(0, 80)}"`);
      return;
    }
    if (isFastPrevRequest(userText) || isUserPrevRequest(userText)) {
      log.info("Fast-path: previous question request");
      handlePreviousTransition().catch(log.error);
      return;
    }
    if (isFastNextRequest(userText)) {
      log.info("Fast-path: next question request");
      handleTransition().catch(log.error);
      return;
    }

    const retryingPendingUserTurnCandidate = isSameAsPendingUserTurn(userText);
    if (
      !options?.allowRecentReplay &&
      !retryingPendingUserTurnCandidate &&
      isDuplicateUserFinal(userText)
    ) {
      log.info(
        `Skipping duplicate USER final (reply already recorded): "${userText.slice(0, 72)}..."`,
      );
      return;
    }

    // A second final can arrive while we're still in handleUserUtterance (LLM/TTS).
    // The client has already received asr_ended — queue and run after this cycle finishes.
    if (generatingResponse) {
      const duplicateWhileGenerating =
        isReplayOfPendingUserTurn(userText) ||
        (!options?.allowRecentReplay && isDuplicateUserFinal(userText));
      if (duplicateWhileGenerating) {
        log.info(
          `Skipping duplicate USER final while response is generating: "${userText.slice(0, 72)}..."`,
        );
        return;
      }
      queuedUserUtteranceWhileGenerating = userText;
      log.info(`Queueing user utterance until current response cycle completes: "${userText.slice(0, 60)}"`);
      return;
    }

    const myEpoch = ++responseEpoch;
    const controller = new AbortController();
    responseController = controller;
    generatingResponse = true;
    if (browserWs.readyState === WebSocket.OPEN) {
      browserWs.send(JSON.stringify({ type: "response_started" }));
    }
    try {
      // User often finishes a phrase right as greeting/answer TTS is still
      // flagged active (barge-in + ASR final ordering). Dropping here leaves
      // the client stuck in isProcessing with no reply — cancel TTS and process.
      if (ttsSpeaking) {
        log.info(`User utterance during TTS — cancelling playback and processing: "${userText.slice(0, 60)}"`);
        cancelTts();
        if (browserWs.readyState === WebSocket.OPEN) {
          browserWs.send(JSON.stringify({ type: "interrupt" }));
        }
      }

      updateUserLanguage(userText);
      const retryingPendingUserTurn = retryingPendingUserTurnCandidate;
      if (retryingPendingUserTurn) {
        log.info(`Retrying response for pending USER final: "${userText.slice(0, 72)}..."`);
      } else {
        rememberAcceptedUserFinal(userText);
        questionTranscript.push({ role: "user", text: userText });
        userTurnsOnCurrentQ++;
      }
      lastResponseWasCorrection = false;

      if (pendingLastQuestionTimeout) {
        clearTimeout(pendingLastQuestionTimeout);
        pendingLastQuestionTimeout = null;
        log.info("User spoke — cancelled pending last-Q transition");
      }

      if (awaitingFinalResponse) {
        awaitingFinalResponse = false;
        if (finalResponseTimeout) {
          clearTimeout(finalResponseTimeout);
          finalResponseTimeout = null;
        }
        const farewell = buildFarewellSayHello(isZh);
        log.info("Final response received, sending farewell");
        await speakAndHandle(farewell, { pendingFarewell: true });
        return;
      }

      const userWantsSkip = isUserSkipRequest(userText);
      if (userWantsSkip) log.info(`User skip intent detected: "${userText.slice(0, 80)}"`);

      // Suppress ASR result processing during the response cycle.
      // ASR stays alive for barge-in detection; reconnected in finally block.
      suppressAsrResults = true;

      cancelTts();
      if (browserWs.readyState === WebSocket.OPEN) {
        browserWs.send(JSON.stringify({ type: "interrupt" }));
      }

      try {
        const response = await generateControlledResponse({ forceSkip: userWantsSkip, signal: controller.signal });

        if (myEpoch !== responseEpoch || controller.signal.aborted || !response || browserWs.readyState !== WebSocket.OPEN) return;

        let shouldTransition = response.includes(NEXT_TOKEN);
        let shouldGoPrev = response.includes(PREV_TOKEN);
        const spokenText = response.replace(NEXT_TOKEN, "").replace(PREV_TOKEN, "").trim();

        if (!shouldTransition && !shouldGoPrev && userTurnsOnCurrentQ > 0
            && hasImplicitTransition(spokenText) && !replyKeepsConversationOpen(spokenText, isZh)) {
          shouldTransition = true;
          log.info("Implicit transition detected in response text");
        }

        if (!shouldGoPrev && !shouldTransition && hasImplicitPrevTransition(spokenText)) {
          shouldGoPrev = true;
          log.info("Implicit PREV transition detected in response text");
        }

        if (
          shouldTransition &&
          !userWantsSkip &&
          replyKeepsConversationOpen(spokenText, isZh)
        ) {
          shouldTransition = false;
          log.info("Stripped transition — spoken response still invites a reply");
        }

        const currentType = sortedQuestions[currentQuestionIndex]?.type;
        if (shouldTransition && !userWantsSkip && (currentType === "CODING" || currentType === "WHITEBOARD")) {
          if (spokenText.length > 80) {
            shouldTransition = false;
            log.info(`Stripped transition — coding/wb response too long (${spokenText.length} chars)`);
          }
        }

        if (spokenText) {
          log.info("Sent controlled response via TTS");
          await speakAndHandle(spokenText, {
            pendingTransition: shouldTransition,
            pendingPrevTransition: shouldGoPrev && currentQuestionIndex > 0,
          });
        } else if (shouldGoPrev && currentQuestionIndex > 0) {
          handlePreviousTransition().catch(log.error);
        } else if (shouldTransition) {
          handleTransition(true).catch(log.error);
        }

        if (pendingWhiteboardVision && !shouldTransition && !shouldGoPrev) {
          scheduleWhiteboardFollowUp();
        }
      } catch (err) {
        if (!controller.signal.aborted) log.error("Response generation failed:", err);
      } finally {
        if (myEpoch !== responseEpoch) return;
        responseController = null;
        generatingResponse = false;
        if (
          !interviewDone &&
          !isTransitioning &&
          browserWs.readyState === WebSocket.OPEN
        ) {
          try {
            await reopenAsr();
            const followUp = queuedUserUtteranceWhileGenerating.trim();
            queuedUserUtteranceWhileGenerating = "";
            if (followUp && !isDuplicateUserFinal(followUp)) {
              await handleUserUtterance(followUp);
            } else if (followUp) {
              log.info(
                `Skipping queued user utterance — duplicate of answered turn: "${followUp.slice(0, 60)}..."`,
              );
            }
          } catch (err) {
            log.error("Post-response reopen/drain failed:", err);
          }
        }
      }
    } finally {
      if (myEpoch === responseEpoch) generatingResponse = false;
    }
  }

  // ── Connect ASR ────────────────────────────────────────────────

  let asrIntentionalClose = false;

  /** Gracefully close the current ASR session (send end-of-stream). */
  function disconnectAsr() {
    asrIntentionalClose = true;
    clearPendingAsrFinal();
    clearHeldBargeInInterim();
    asrRotationPending = false;
    pendingAsrRotationAudio.length = 0;
    if (keepAliveInterval) {
      clearInterval(keepAliveInterval);
      keepAliveInterval = null;
    }
    if (asrWs && asrWs.readyState === WebSocket.OPEN && asrAlive) {
      try {
        asrAudioSeq++;
        asrWs.send(buildBigModelAudioRequest(Buffer.alloc(0), asrAudioSeq, true));
      } catch { /* ignore */ }
    }
    if (asrWs) {
      closeDetachedAsrSocket(asrWs);
    }
    asrWs = null;
    asrAlive = false;
    asrSessionFirstSpeechAt = 0;
    log.info("ASR disconnected (intentional)");
  }

  /** Reconnect ASR after response cycle so accumulated echo text is cleared. */
  async function reopenAsr() {
    if (
      interviewDone || sessionPaused ||
      isTransitioning ||
      browserWs.readyState !== WebSocket.OPEN
    ) {
      return;
    }

    try {
      await connectAsr();
      if (
        interviewDone || sessionPaused ||
        isTransitioning ||
        browserWs.readyState !== WebSocket.OPEN
      ) {
        disconnectAsr();
        return;
      }
      if (!keepAliveInterval) {
        keepAliveInterval = setInterval(() => {
          if (!asrAlive || !asrWs || asrWs.readyState !== WebSocket.OPEN) return;
          asrAudioSeq++;
          asrWs.send(buildBigModelAudioRequest(Buffer.alloc(3200), asrAudioSeq));
        }, 5000);
      }
      // Only clear suppression if no new response cycle is running
      if (!generatingResponse) {
        suppressAsrResults = false;
      }

      const flushed = pendingUserUtteranceWhileSuppressed.trim();
      pendingUserUtteranceWhileSuppressed = "";
      if (
        flushed &&
        !interviewDone &&
        browserWs.readyState === WebSocket.OPEN &&
        !looksLikeAssistantPlaybackEcho(flushed, questionTranscript) &&
        !isDuplicateUserFinal(flushed) &&
        !shouldIgnoreVolcContinuationFragment(
          flushed,
          questionTranscript,
          lastAssistantMessageWallClockMs,
          isZh,
        )
      ) {
        log.info(`ASR suppression flush — deferred user: "${flushed.slice(0, 72)}..."`);
        browserWs.send(JSON.stringify({
          type: "asr",
          data: { results: [{ text: flushed, definite: true }] },
        }));
        browserWs.send(JSON.stringify({ type: "asr_ended", text: flushed }));
        await handleUserUtterance(flushed);
      } else if (flushed && isDuplicateUserFinal(flushed)) {
        log.info(
          `ASR suppression flush skipped — duplicate USER final (already answered): "${flushed.slice(0, 72)}..."`,
        );
      } else if (
        flushed &&
        shouldIgnoreVolcContinuationFragment(
          flushed,
          questionTranscript,
          lastAssistantMessageWallClockMs,
          isZh,
        )
      ) {
        log.info(
          `ASR suppression flush skipped — split-noise fragment: "${flushed.slice(0, 72)}..."`,
        );
      }

      log.info("ASR reconnected — ready for user input");
    } catch (err) {
      log.error("ASR reopen failed:", err instanceof Error ? err.message : err);
      autoReconnectAsr().catch((reconnectErr) => {
        log.error("All ASR reconnect attempts failed:", reconnectErr instanceof Error ? reconnectErr.message : reconnectErr);
        if (browserWs.readyState === WebSocket.OPEN) {
          browserWs.send(JSON.stringify({ type: "disconnected" }));
          browserWs.close();
        }
      });
    }
  }

  function buildAsrContext(): Record<string, unknown> | undefined {
    const contextData: { text: string }[] = [];

    const currentQ = sortedQuestions[currentQuestionIndex];
    if (currentQ) {
      contextData.push({ text: `Interview topic: ${ctx.title}` });
      contextData.push({ text: `Current question: ${currentQ.text}` });
    }

    const recentTranscript = questionTranscript.slice(-6);
    for (const entry of recentTranscript) {
      contextData.push({ text: `${entry.role}: ${entry.text}` });
    }

    if (contextData.length === 0) return undefined;
    return {
      context: JSON.stringify({
        context_type: "dialog_ctx",
        context_data: contextData,
      }),
    };
  }

  async function connectAsr() {
    asrIntentionalClose = false;
    const reqid = randomUUID().replace(/-/g, "");
    asrAudioSeq = 1;
    // Each websocket reports a cumulative transcript of its own audio only.
    resetAsrSessionState(asrSession);

    const asrConfig: BigModelAsrConfig = {
      language: resolveBigModelAsrLanguage(ctx.language),
      format: "pcm",
      rate: 16000,
      bits: 16,
      channels: 1,
      codec: "raw",
      showUtterance: true,
      resultType: "full",
      enablePunc: true,
      enableDdc: true,
      endWindowSize: ASR_END_WINDOW_MS,
      forceToSpeechTime: ASR_FORCE_SPEECH_MS,
      enableNonstream: true,
      ssdVersion: "200",
      corpus: buildAsrContext(),
    };

    if (asrWs) {
      closeDetachedAsrSocket(asrWs);
    }

    const wsHeaders = buildBigModelHeaders(
      ASR_APP_ID, ASR_ACCESS_TOKEN, reqid, ASR_RESOURCE_ID,
      ASR_API_KEY || undefined,
    );
    asrWs = new WebSocket(BIGMODEL_ASR_URL, { headers: wsHeaders });

    await new Promise<void>((resolve, reject) => {
      const t = setTimeout(() => reject(new Error("ASR connect timeout")), 10000);
      asrWs!.on("open", () => { clearTimeout(t); resolve(); });
      asrWs!.on("error", (e) => { clearTimeout(t); reject(e); });
      asrWs!.on("unexpected-response", (_req, res) => {
        let body = "";
        res.on("data", (chunk: Buffer) => { body += chunk.toString(); });
        res.on("end", () => {
          clearTimeout(t);
          log.error(`ASR WebSocket rejected: HTTP ${res.statusCode} — ${body}`);
          reject(new Error(`ASR server responded ${res.statusCode}: ${body}`));
        });
      });
    });
    log.info(`ASR connected: resource=${ASR_RESOURCE_ID}`);

    asrWs.send(buildBigModelFullRequest(asrConfig, reqid));
    asrAlive = true;

    if (asrRotationPending) {
      const bufferedChunks = pendingAsrRotationAudio.length;
      while (
        pendingAsrRotationAudio.length > 0 &&
        asrWs.readyState === WebSocket.OPEN
      ) {
        const pcm = pendingAsrRotationAudio.shift();
        if (!pcm) break;
        asrAudioSeq++;
        asrWs.send(buildBigModelAudioRequest(pcm, asrAudioSeq));
      }
      asrRotationPending = false;
      if (bufferedChunks > 0) {
        log.info(`ASR rotation replayed ${bufferedChunks} buffered audio chunk(s)`);
      }
    }

    asrWs.on("message", (data: Buffer) => {
      try {
        const resp = parseAsrResponse(Buffer.from(data));

        if (resp.errorCode != null) {
          log.error(`ASR error: ${resp.errorCode} ${resp.errorMessage}`);
          return;
        }

        if (interviewDone || sessionPaused) return;

        // Volcengine resends the whole session transcript on every packet, so derive the one
        // uncommitted update it represents instead of replaying each finished segment.
        const update = deriveAsrSessionUpdate(asrSession, resp);

        if (!update.text) {
          if (resp.messageType !== 1 && resp.messageType !== 9) {
            log.info(`ASR non-text msg: type=${resp.messageType}, code=${resp.code}, seq=${resp.sequence}`);
          }
          return;
        }

        // A repeat of an already-settled segment says nothing new.
        if (!update.changed) return;

        const definite = update.definite;
        let text = update.text;

        // Reject before either barge-in, semantic decisions or deferred-turn queues can run.
        if (protectPlayback && (playbackEchoGuard.isBlocked(Date.now()) || playbackEchoGuard.isEcho(text, Date.now()))) {
          markAsrSessionCommitted(asrSession);
          return;
        }

        // Server-side barge-in: interim speech during TTS → cancel TTS immediately
        if (shouldHoldBargeInInterimForFinal({
          text,
          definite,
          ttsSpeaking,
          endingInterview,
        })) {
          log.info(`Barge-in detected via ASR (interim: "${text.slice(0, 40)}") — cancelling TTS`);
          holdBargeInInterim(text);
          cancelTts();
          suppressAsrResults = false;
          cancelResponse();
          if (browserWs.readyState === WebSocket.OPEN) {
            browserWs.send(JSON.stringify({ type: "interrupt" }));
            browserWs.send(JSON.stringify({ type: "response_cancelled" }));
          }
          return;
        }

        if (heldBargeInInterimText && text.trim()) {
          text = mergeAsrSegments(heldBargeInInterimText, text);
          clearHeldBargeInInterim();
        }

        // During suppression, defer user finals for flush after reopenAsr.
        // Echo of TTS is mostly definite; we guard on flush. Forward interims
        // only when not playing TTS so live captions work during LLM wait.
        if (suppressAsrResults) {
          const suppressedText = text.trim();
          if (
            suppressedText.length >= 2 &&
            !definite &&
            !ttsSpeaking &&
            browserWs.readyState === WebSocket.OPEN &&
            !isDuplicateUserFinal(suppressedText) &&
            !shouldIgnoreVolcContinuationFragment(
              suppressedText,
              questionTranscript,
              lastAssistantMessageWallClockMs,
              isZh,
            )
          ) {
            browserWs.send(JSON.stringify({
              type: "asr",
              data: { results: [{ text: suppressedText, definite }] },
            }));
          }
          if (definite) {
            if (suppressedText.length >= 2) {
              if (
                shouldIgnoreVolcContinuationFragment(
                  suppressedText,
                  questionTranscript,
                  lastAssistantMessageWallClockMs,
                  isZh,
                )
              ) {
                return;
              }
              const prevPending = pendingUserUtteranceWhileSuppressed.trim();
              const incomingDup = isDuplicateUserFinal(suppressedText);
              const sameAsPending =
                normalizeUserUtteranceKey(suppressedText)
                === normalizeUserUtteranceKey(prevPending);

              // Volc can emit a late duplicate definite for an old turn after a newer utterance
              // was deferred here — blindly overwriting would drop the real follow-up on flush.
              if (
                prevPending &&
                incomingDup &&
                !sameAsPending
              ) {
                log.info(
                  `Keeping deferred utterance — ignoring stale duplicate: "${suppressedText.slice(0, 72)}..."`,
                );
              } else if (!incomingDup || sameAsPending) {
                pendingUserUtteranceWhileSuppressed = suppressedText;
              } else if (!prevPending) {
                log.info(
                  `Suppressed ASR final skipped (already answered, nothing deferred): "${suppressedText.slice(0, 72)}..."`,
                );
              }
            }
          }
          return;
        }

        if (endingInterview) return;

        if (!asrSessionFirstSpeechAt && text.trim()) {
          asrSessionFirstSpeechAt = Date.now();
        }

        const pendingText = pendingTextForSessionUpdate(text);
        if (ctx.turnTaking === "MANUAL") {
          if (pendingText.trim().length >= 2) schedulePendingAsrFinal(pendingText, definite ? "definite" : "interim");
          return;
        }

        if (!definite) {
          sendAsrInterim(pendingText);
          trackAsrInterimStall(pendingText);

          // Speech resumed after an endpoint (a short pause mid-answer): keep the turn open
          // and push the commit out so the rest of the sentence lands in the same turn.
          if (pendingAsrFinalText) {
            // Only real growth restarts the quiet clock. `definite` can flip back to false with the
            // wording unchanged, and treating that as new speech re-armed the timer indefinitely,
            // which also hid the stuck-text and max-hold safety valves that key off this timestamp.
            const grew =
              normalizeUserUtteranceKey(pendingAsrFinalText)
              !== normalizeUserUtteranceKey(pendingText);
            pendingAsrFinalText = pendingText;
            if (grew) pendingAsrFinalLastChangedAt = Date.now();
            if (pendingAsrFinalTimer) {
              clearTimeout(pendingAsrFinalTimer);
            }
            const delay = pendingAsrFinalDelay(pendingText);
            pendingAsrFinalTimer = setTimeout(() => {
              flushPendingAsrFinal("coalesced");
            }, delay);
            sendAsrPending(pendingText, delay);
            log.info(`ASR continuation merged: "${pendingText.slice(0, 80)}"`);
          }
          return;
        }

        clearAsrInterimStall();

        const finalText = pendingText.trim();
        if (finalText.length >= 2) {
          schedulePendingAsrFinal(finalText, "definite");
        } else {
          clearPendingAsrFinal();
        }
      } catch (err) {
        log.error("ASR parse error:", err);
      }
    });

    asrWs.on("close", (code: number, reason: Buffer) => {
      const reasonStr = reason?.toString() || "";
      log.warn(`ASR WS closed (code=${code}, reason="${reasonStr}")`);
      asrAlive = false;

      // Don't auto-reconnect if we intentionally closed (will reopen later)
      if (asrIntentionalClose) return;
      if (isTransitioning || interviewDone || sessionPaused) return;
      if (browserWs.readyState !== WebSocket.OPEN) return;

      autoReconnectAsr().catch((err) => {
        log.error("All ASR reconnect attempts failed:", err instanceof Error ? err.message : err);
        if (browserWs.readyState === WebSocket.OPEN) {
          browserWs.send(JSON.stringify({ type: "disconnected" }));
          browserWs.close();
        }
      });
    });

    asrWs.on("error", (err: Error) => {
      log.error(`ASR WS error: ${err.message}`);
    });

    log.info("ASR 2.0 connected");
  }

  const MAX_RECONNECT_ATTEMPTS = 3;
  const RECONNECT_DELAY_MS = 1000;

  async function autoReconnectAsr(): Promise<void> {
    if (sessionPaused || interviewDone) return;
    browserWs.send(JSON.stringify({ type: "session_reconnecting" }));

    for (let attempt = 1; attempt <= MAX_RECONNECT_ATTEMPTS; attempt++) {
      if (sessionPaused || interviewDone || browserWs.readyState !== WebSocket.OPEN) return;

      const delay = RECONNECT_DELAY_MS * attempt;
      log.info(`ASR auto-reconnect attempt ${attempt}/${MAX_RECONNECT_ATTEMPTS} (waiting ${delay}ms)...`);
      await new Promise((r) => setTimeout(r, delay));

      if (sessionPaused || interviewDone || browserWs.readyState !== WebSocket.OPEN) return;

      try {
        await connectAsr();

        if (!keepAliveInterval) {
          keepAliveInterval = setInterval(() => {
            if (!asrAlive || !asrWs || asrWs.readyState !== WebSocket.OPEN) return;
            asrAudioSeq++;
            asrWs.send(buildBigModelAudioRequest(Buffer.alloc(3200), asrAudioSeq));
          }, 5000);
        }

        browserWs.send(JSON.stringify({ type: "session_reconnected" }));
        log.info(`ASR auto-reconnect succeeded on attempt ${attempt}`);
        return;
      } catch (err) {
        log.warn(`ASR auto-reconnect attempt ${attempt} failed:`, err instanceof Error ? err.message : err);
      }
    }

    throw new Error("Exhausted all reconnect attempts");
  }

  // ── Initialize ─────────────────────────────────────────────────

  const greeting = currentQuestionIndex > 0
    ? buildResumeGreeting(ctx, currentQuestionIndex)
    : buildGreeting(ctx);

  log.info("Greeting:", greeting.slice(0, 200) + "...");

  try {
    await connectAsr();

    browserWs.send(JSON.stringify({ type: "ready", sessionId: randomUUID() }));

    browserWs.send(
      JSON.stringify({
        type: "question_change",
        questionIndex: currentQuestionIndex,
        totalQuestions: sortedQuestions.length,
      })
    );

    suppressAsrResults = true;
    log.info(`Starting greeting TTS for Q${currentQuestionIndex + 1}`);
    speakAndHandle(greeting, { trackInTranscript: false })
      .then(() => {
        if (!interviewDone && browserWs.readyState === WebSocket.OPEN) {
          // Reconnect ASR to clear echo accumulated during greeting TTS
          reopenAsr().catch(log.error);
        }
      })
      .catch(log.error);
  } catch (err) {
    log.error("Failed to initialize:", err);
    browserWs.send(
      JSON.stringify({
        type: "error",
        message: `Connection failed: ${err instanceof Error ? err.message : err}`,
      })
    );
    browserWs.close();
    return;
  }

  // ── Browser message handling ────────────────────────────────────

  function pauseInterview() {
    if (sessionPaused || interviewDone) return;
    sessionPaused = true;
    pausedAnswer = pendingAsrFinalText || asrInterimStallText || pendingUserUtteranceWhileSuppressed || pausedAnswer;
    pausedResponsePending = pausedResponsePending || (generatingResponse && questionTranscript.at(-1)?.role === "user");
    // A second pause during "welcome back" must keep the original unfinished turn.
    if (ttsSpeaking && currentSpeech !== "欢迎回来。" && currentSpeech !== "Welcome back.") {
      pausedSpeech = currentSpeech;
      pausedSpeechActions = currentSpeechActions;
    }
    // If a transition has already advanced the index, resume its unanswered question.
    if (isTransitioning && !pausedSpeech) {
      pausedSpeech = sortedQuestions[currentQuestionIndex]?.text || buildWrapUpSayHello(isZh);
      if (currentQuestionIndex >= sortedQuestions.length) awaitingFinalResponse = true;
      pausedSpeechActions = { trackInTranscript: false, pendingFinalTimeout: awaitingFinalResponse };
    }
    transitionGeneration++;
    isTransitioning = false;
    pendingManualTransitionDirection = null;
    cancelResponse(); cancelTts(); disconnectAsr();
    pendingUserUtteranceWhileSuppressed = "";
    queuedUserUtteranceWhileGenerating = "";
    if (finalResponseTimeout) clearTimeout(finalResponseTimeout);
    if (pendingLastQuestionTimeout) clearTimeout(pendingLastQuestionTimeout);
    finalResponseTimeout = pendingLastQuestionTimeout = null;
    browserWs.send(JSON.stringify({ type: "session_paused", questionIndex: currentQuestionIndex }));
  }

  async function resumeInterview() {
    if (!sessionPaused || interviewDone) return;
    sessionPaused = false;
    const resumeGeneration = transitionGeneration;
    const retryResponse = pausedResponsePending;
    const speech = pausedSpeech;
    const speechActions = pausedSpeechActions;
    const answer = pausedAnswer;
    suppressAsrResults = true;
    browserWs.send(JSON.stringify({ type: "session_resumed", questionIndex: currentQuestionIndex }));
    await speakAndHandle(isZh ? "欢迎回来。" : "Welcome back.", { trackInTranscript: false });
    if (sessionPaused || interviewDone || resumeGeneration !== transitionGeneration || browserWs.readyState !== WebSocket.OPEN) return;
    pausedResponsePending = false; pausedSpeech = "";
    if (speech) {
      await speakAndHandle(speech, speechActions);
    } else if (retryResponse) {
      const lastUser = questionTranscript.findLast(e => e.role === "user")?.text;
      if (lastUser) await handleUserUtterance(lastUser, { allowRecentReplay: true });
    }
    if (sessionPaused || interviewDone || resumeGeneration !== transitionGeneration) return;
    await reopenAsr();
    if (sessionPaused || interviewDone || resumeGeneration !== transitionGeneration) return;
    if (answer) {
      // Pausing is not submitting: keep the draft until more speech or an explicit finish.
      pendingAsrFinalPrefix = answer;
      pendingAsrFinalText = answer;
      pendingAsrFinalStartedAt = pendingAsrFinalLastChangedAt = Date.now();
      browserWs.send(JSON.stringify({ type: "asr_pending", text: answer, manual: true }));
    }
    pausedAnswer = "";
  }

  browserWs.on("message", (data) => {
    try {
      const msg = JSON.parse(data.toString());

      if (msg.type === "pause_session") { pauseInterview(); return; }
      if (msg.type === "resume_session") { void resumeInterview().catch(log.error); return; }
      if (sessionPaused && msg.type !== "ping") return;

      if (msg.type === "audio" && msg.data) {
        const incoming = Buffer.from(msg.data, "hex");
        const pcm = protectPlayback && playbackEchoGuard.isBlocked(Date.now())
          ? Buffer.alloc(incoming.length) : incoming;
        noteIncomingAudioActivity(pcm);
        if (isTransitioning) return;
        if (!asrAlive || !asrWs || asrWs.readyState !== WebSocket.OPEN) {
          if (asrRotationPending) {
            pendingAsrRotationAudio.push(pcm);
            while (pendingAsrRotationAudio.length > ASR_MAX_PENDING_CHUNKS) {
              pendingAsrRotationAudio.shift();
            }
          }
          return;
        }
        asrAudioSeq++;
        asrWs.send(buildBigModelAudioRequest(pcm, asrAudioSeq));
      } else if (msg.type === "barge_in") {
        if (protectPlayback && playbackEchoGuard.isBlocked(Date.now())) return;
        if (ttsSpeaking || generatingResponse) {
          log.info("Client barge-in signal received — cancelling TTS");
          cancelTts();
          suppressAsrResults = false;
          cancelResponse();
          if (browserWs.readyState === WebSocket.OPEN) {
            browserWs.send(JSON.stringify({ type: "interrupt" }));
            browserWs.send(JSON.stringify({ type: "response_cancelled" }));
          }
        }
      } else if (msg.type === "finish_answer") {
        if (!interviewDone && !isTransitioning && !generatingResponse && !ttsSpeaking && !manualSubmitTimer) {
          // Allow the recognizer to deliver the last syllable after the explicit button press.
          manualSubmitTimer = setTimeout(() => {
            manualSubmitTimer = null;
            if (pendingAsrFinalText.trim().length < 2) {
              browserWs.send(JSON.stringify({ type: "response_cancelled" }));
              return;
            }
            flushPendingAsrFinal("explicit finish", true);
          }, 750);
        }
      } else if (msg.type === "playback_ended") {
        const playbackAck = pendingPlaybackAck;
        if (
          playbackAck &&
          typeof msg.utteranceId === "string" &&
          playbackAck.utteranceId === msg.utteranceId
        ) {
          log.debug(`Browser playback completed (${msg.utteranceId})`);
          playbackAck.complete();
        }
      } else if (msg.type === "text_input" && msg.content) {
        const userText = (msg.content as string).trim();
        if (userText && !isTransitioning && !interviewDone) {
          const source = typeof msg.source === "string" ? msg.source : "";
          if (protectPlayback && source === "asr_interim_watchdog" &&
            (playbackEchoGuard.isBlocked(Date.now()) || playbackEchoGuard.isEcho(userText, Date.now()))) return;
          if (ctx.turnTaking === "MANUAL" && source === "asr_interim_watchdog") return;
          if (source === "asr_interim_watchdog" && shouldIgnoreAsrInterimReplay(userText)) {
            log.info(`ASR interim replay skipped — stale tail fragment: "${userText.slice(0, 72)}..."`);
            if (browserWs.readyState === WebSocket.OPEN) {
              browserWs.send(JSON.stringify({ type: "interrupt" }));
            }
            return;
          }

          cancelTts();
          browserWs.send(JSON.stringify({ type: "interrupt" }));
          browserWs.send(JSON.stringify({
            type: "asr_ended",
            text: userText,
            ...(source === "chat" ? { source: "chat" } : {}),
          }));
          handleUserUtterance(userText).catch(log.error);
          log.info(`Text input${source ? ` (${source})` : ""}: "${userText.slice(0, 60)}..."`);
        }
      } else if (msg.type === "next_question") {
        log.info("Browser requested next question");
        handleTransition().catch(log.error);
      } else if (msg.type === "prev_question") {
        log.info("Browser requested previous question");
        handlePreviousTransition().catch(log.error);
      } else if (msg.type === "text" && msg.content) {
        speakText(msg.content).catch(log.error);
      } else if (msg.type === "code_update") {
        currentCodeContent = (msg.content as string) || "";
        currentCodeLanguage = (msg.language as string) || "plaintext";
      } else if (msg.type === "whiteboard_update") {
        const img = (msg.imageDataUrl as string) || "";
        const requestId = typeof msg.requestId === "string" ? msg.requestId : "";
        if (img && img !== latestWhiteboardImage) {
          latestWhiteboardImage = img;
          whiteboardDirty = true;
          log.info(`Whiteboard update received (${Math.round(img.length / 1024)}KB, dirty=true)`);
        }
        if (requestId) {
          settleWhiteboardSnapshotRequest(requestId, Boolean(img));
        } else if (img) {
          settleAllWhiteboardSnapshotRequests(true);
        }
      } else if (msg.type === "whiteboard_snapshot_unavailable") {
        const requestId = typeof msg.requestId === "string" ? msg.requestId : "";
        if (requestId) {
          settleWhiteboardSnapshotRequest(requestId, false);
        }
      } else if (msg.type === "ping") {
        browserWs.send(JSON.stringify({ type: "pong" }));
      }
    } catch (err) {
      log.error("Error handling browser message:", err);
    }
  });

  browserWs.on("close", () => {
    log.info("Browser disconnected");
    interviewDone = true;
    cancelResponse();
    clearPendingAsrFinal();
    settleAllWhiteboardSnapshotRequests(false);
    cancelTts();
    if (keepAliveInterval) { clearInterval(keepAliveInterval); keepAliveInterval = null; }
    if (finalResponseTimeout) clearTimeout(finalResponseTimeout);
    if (pendingLastQuestionTimeout) clearTimeout(pendingLastQuestionTimeout);
    if (asrAlive && asrWs && asrWs.readyState === WebSocket.OPEN) {
      try {
        asrAudioSeq++;
        asrWs.send(buildBigModelAudioRequest(Buffer.alloc(0), asrAudioSeq, true));
      } catch { /* ignore */ }
    }
    closeDetachedAsrSocket(asrWs);
  });

  browserWs.on("error", (err) => {
    log.error("Browser WS error:", err.message);
  });

  // ── Keep-alive: send silence periodically for ASR ──────────────

  keepAliveInterval = setInterval(() => {
    if (!asrAlive || !asrWs || asrWs.readyState !== WebSocket.OPEN) return;
    asrAudioSeq++;
    asrWs.send(buildBigModelAudioRequest(Buffer.alloc(3200), asrAudioSeq));
  }, 5000);
}
