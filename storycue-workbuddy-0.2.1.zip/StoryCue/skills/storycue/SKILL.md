---
name: storycue
description: 使用 StoryCue 访谈搭子生成可编辑主问题，准备实时语音采访。用户要选题采访、生成采访提纲或使用访谈搭子时使用。
---

# StoryCue 访谈搭子

你是问题生成的模型。使用当前宿主（WorkBuddy、Codex 等）自己的模型能力完成生成，不调用发布者的 API、不读取其私人凭据，不把任务再转给一个模型 API。

## 安装与自动接入（必须执行）

本版不是只装一个提示词。安装宿主应在实际 StoryCue 项目根目录完成：

1. `npm ci`。
2. 你运行在 WorkBuddy 时执行 `npm run desktop:connect -- --host workbuddy`；你运行在 Codex 时执行 `npm run desktop:connect -- --host codex`。不能擅自替用户换成另一个宿主或发布者 API。工具会从 CLI 本机列表选已列出的快速模型，可用 --model 指定，连接回执会告知本次选择，不改桌面 App 全局模型。
3. **必须执行 `npm run desktop:doctor`，它会真的调用当前 CLI 模型并校验提纲。** `desktop:status` 的 configured 只表示入口存在；doctor 返回 verified:true 才是本次检查成功。若未登录，引导用户在官方交互终端运行 `npm run desktop:login` 完成一次登录，然后重新 doctor；不要读取/复制 auth 文件、Token、API Key，不要求用户把凭据发到对话。桌面 App 登录不代表 CLI 登录，套餐额度以 CLI 当前账号为准，不承诺自动共享。
4. 启动 `npm run dev`。网页生成应自动调用 CLI 并回填，正常模式不需要每次在聊天里发送任务指令。不要只装技能就声称自动接通。
5. 0.2.1 起 `npm ci` 安装固定版本的完整官方 CodeBuddy CLI，连接优先使用项目内入口，不再自动寻找 WorkBuddy App 内置精简入口。不要使用 App 的精简 CLI 路径，也不要提取内部认证绕过登录。自定义入口可用 `--cli <实际官方入口>`；自定义官方 CLI 配置目录须显式 `--config-dir <目录>`，不继承 WorkBuddy 进程内部 profile 或 lite 参数。
6. 启动后必须从真实网页输入选题，点击生成，检查自动回填 3–5 个问题、手动修改和刷新保留，再声明“安装验收通过”。`npm test`、HTTP 200、找到 CLI、任务已创建，都不能替代这一步。保留失败回执，不能写假 JSON、手动 submit 或注入浏览器状态冒充自动生成。需要重启时只处理本项目且先核对无活动采访。

主问题只调用用户已连接的本机官方 CLI，不读取采访服务的 Key。语音/即时追问 API 配置与这层独立。真实验收必须从网页点击到模型生成、自动回填、手动修改；测试假 JSON 只能叫回归，不能冒充实际宿主输出。

## 检查旧任务或主动选择的手动模式

以下仅用于排障/恢复，或 `STORYCUE_DESKTOP_HOST=manual` 的显式手动模式，不作为正常自动使用流程：

1. 在启动网页的同一项目根目录运行 `node --import tsx tools/storycue-agent.ts pending`，核对用户指定的任务编号。
2. `node --import tsx tools/storycue-agent.ts prompt --id <编号>` 读取本轮 input 和 prompt。找不到编号先检查两份项目或数据目录不一致，不能另建任务冒充恢复。
3. 按当前方向，由你自己生成 3–5 个主问题 JSON，包含支撑/经历、金句提炼和最后的转化承接。不预写嘉宾答案或事实。按工具返回 prompt 执行，不用聊天记忆代替。
4. 将 JSON 存入 `.storycue-work/` 或项目外临时目录，然后 `node --import tsx tools/storycue-agent.ts submit --id <编号> --file <JSON路径>`。格式/方向不合格按回执修正；不改任务存储、不放宽检查、不覆盖完成结果。
5. 网页自动收到结果，允许手改；不要替用户开始麦克风。未连接、未登录或失败必须说清实际状态，不把“任务存在”当作“模型已调用”。

## 运行服务

`npm run dev` 启动本地网页和语音服务；使用宿主正式后台命令工具保持运行，不通过终端 UI 或隐藏脚本绕过。服务默认仅本机，不停止旧项目服务。配置缺少时请用户在网页本地配置页面填写自己的 Key，不让用户把 Key 发到对话里；密钥不能出现在回复或日志中。

首次安装必须解释两套独立服务，再引导用户打开 `/trial/setup`：

- **语音（听与说）**：豆包语音 API Key；ASR/TTS 地址已内置，无需用户填写。Key 来自火山引擎语音服务，需具备识别和合成权限，不等同于方舟文本服务 Key。
- **即时追问（文本思考）**：由用户自由选服务商，填写该服务的 **Base URL + API Key + 模型名/接入点 ID**，三者配套；不要默认只能用豆包。支持 OpenAI Chat Completions 兼容接口（Bearer 认证、SSE 流式和标准 messages/temperature/max_tokens），仅其他协议的接口不能保证直接可用。优先快速、直接输出答案的模型。
- 文本 Base URL 只控制即时追问、剪辑建议及用户主动启用的 API 提纲模式，不改变豆包语音地址；不要在 Base URL 后再加 `/chat/completions`，工具自动拼接。语音和文本服务分别计费。
- 当前网页可读取已保存的非敏感地址/模型名，Key 始终不回显。同服务留空保留 Key；换文本服务地址时需要新 Key，避免把旧服务 Key 发给新服务。保存后重启 **StoryCue 自己**的启动器，不重启其他项目。
- `RELAY_LLM_THINKING=auto` 是兼容默认：只对内置方舟地址请求关闭思考，其他服务不发送豆包专用参数。不能承诺任意推理模型都会自动关闭思考或达到固定响应速度。

## 范围

当前只将批量主问题生成交给已连接的官方本机 CLI（或显式手动模式宿主）。实时识别、语音播报、即时追问和剪辑建议使用用户配置的服务。默认自动停顿接话，无需 Jev、无需逐次点击提交。Jev 只在用户主动启用并配置时使用。未知事实、未实现功能和没有实际运行的链路要明确说明。

## 升级用户

0.1.x / 0.2.0 用户必须更新源码和本技能，保留 .env.local、.storycue-data 及现有浏览器记录，再 npm ci、desktop:connect 和 desktop:doctor，随后重启本项目服务。旧精简入口配置不能沿用。不要删除旧任务/记录。仅刷新页面、npm test 或继续使用旧的手动技能，不算升级成功。
